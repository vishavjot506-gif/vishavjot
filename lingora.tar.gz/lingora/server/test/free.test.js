import './env.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/app.js';
import { openDb } from '../src/db.js';
import * as free from '../src/free.js';

let server, base, token;
const calls = [];
test.before(async () => {
  server = createApp({ db: openDb(':memory:') }).listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  // Fake MyMemory: "<langpair>|<q>" so we can assert what was requested. No real network.
  free.setHttp(async (url) => {
    const u = new URL(url); calls.push(u);
    return { ok: true, json: async () => ({ responseStatus: 200, responseData: { translatedText: `[${u.searchParams.get('langpair')}] ${u.searchParams.get('q')}` } }) };
  });
  free.setOcr(async (_buf, langs) => (langs.includes('tha') ? 'ผัดไทย กุ้ง' : ''));
  const r = await fetch(base + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'f@x.com', password: 'password1' }) });
  token = (await r.json()).token;
  await call('/me', { method: 'PATCH', body: { nativeLang: 'hi', preferredLangs: ['th'] } });
});
test.after(() => server.close());

const call = async (path, { method = 'GET', body, form } = {}) => {
  const headers = { Authorization: `Bearer ${token}` };
  if (body) headers['Content-Type'] = 'application/json';
  const res = await fetch(base + path, { method, headers, body: form ?? (body ? JSON.stringify(body) : undefined) });
  const ct = res.headers.get('content-type') || '';
  return { status: res.status, data: ct.includes('json') ? await res.json() : null };
};

test('free is the default engine and the 6 agents are listed', async () => {
  assert.equal((await call('/me')).data.user.engine, 'free');
  const e = await (await fetch(base + '/engines')).json();
  assert.deepEqual(e.agents.map((a) => a.name), ['listener', 'detector', 'translator', 'voice', 'vision', 'phrases']);
});

test('free translation detects the source language offline and calls the free service', async () => {
  const r = await call('/translate/text', { method: 'POST', body: { text: 'Where is the nearest train station please?' } });
  assert.equal(r.status, 200);
  assert.equal(r.data.source, 'en');
  assert.match(r.data.translation, /^\[en\|hi\]/);
});

test('free translation respects an explicit source and skips work when source == target', async () => {
  const n = calls.length;
  const same = await call('/translate/text', { method: 'POST', body: { text: 'नमस्ते', source: 'hi', target: 'hi' } });
  assert.equal(same.data.translation, 'नमस्ते'); assert.equal(calls.length, n);
  const th = await call('/translate/text', { method: 'POST', body: { text: 'สวัสดี', source: 'th' } });
  assert.match(th.data.translation, /^\[th\|hi\]/);
});

test('long text is split into <=500 byte pieces', async () => {
  const text = 'This is a sentence about travel. '.repeat(40);
  const n = calls.length;
  await call('/translate/text', { method: 'POST', body: { text, source: 'en' } });
  assert.ok(calls.length - n >= 3);
  for (const u of calls.slice(n)) assert.ok(Buffer.byteLength(u.searchParams.get('q')) <= 500);
});

test('repeated translations are served from cache without using quota', async () => {
  free.clearTranslationCache();
  const n = calls.length;
  const a = await call('/translate/text', { method: 'POST', body: { text: 'Good morning my friend', source: 'en' } });
  const b = await call('/translate/text', { method: 'POST', body: { text: 'Good morning my friend', source: 'en' } });
  assert.equal(a.data.translation, b.data.translation);
  assert.equal(calls.length - n, 1);
});

test('picks the exact-sentence machine translation over a wrong crowd-sourced headline (real MyMemory case)', () => {
  const j = { responseStatus: 200, responseData: { translatedText: 'Bharthana\nKa time', match: 0.87 }, matches: [
    { segment: 'Where is the train station?', translation: 'Bharthana\nKa time', quality: '100', match: 0.87 },
    { segment: 'Where is the nearest train station?', translation: 'सबसे नज़दीकी रेलवे स्टेशन कहाँ है?', quality: '70', match: 0.85 },
    { segment: 'Where is the train?', translation: 'ट्रेन कहाँ है?', quality: '0', match: 0.75 }] };
  assert.equal(free.pickBest(j, 'Where is the nearest train station?', 'hi'), 'सबसे नज़दीकी रेलवे स्टेशन कहाँ है?');
  // headline is fine and nothing better exists -> keep it
  assert.equal(free.pickBest({ responseData: { translatedText: 'नमस्ते', match: 1 }, matches: [] }, 'Hello', 'hi'), 'नमस्ते');
});

test('quota exhaustion gives a clear 429', async () => {
  free.clearTranslationCache();
  free.setHttp(async () => ({ ok: true, json: async () => ({ responseStatus: 429, quotaFinished: true }) }));
  const r = await call('/translate/text', { method: 'POST', body: { text: 'hello', source: 'en' } });
  assert.equal(r.status, 429); assert.match(r.data.error, /limit/i);
});

test('free engine has no server speech or voice, and says what to do', async () => {
  const f = new FormData(); f.append('audio', new Blob(['hello world']), 'a.webm');
  const s = await call('/speech/translate', { method: 'POST', form: f });
  assert.equal(s.status, 400); assert.match(s.data.error, /browser/i);
  assert.equal((await call('/tts', { method: 'POST', body: { text: 'hi' } })).status, 400);
});

test('free camera: OCR then translate, and no text -> found:false', async () => {
  free.setHttp(async (url) => { const u = new URL(url); return { ok: true, json: async () => ({ responseStatus: 200, responseData: { translatedText: 'Pad Thai shrimp' } }) }; });
  const f = new FormData(); f.append('image', new Blob(['x'], { type: 'image/png' }), 'm.png');
  const v = await call('/vision/translate', { method: 'POST', form: f });
  assert.equal(v.data.found, true); assert.equal(v.data.source, 'th'); assert.equal(v.data.translation, 'Pad Thai shrimp');
  free.setOcr(async () => '   ');
  const g = new FormData(); g.append('image', new Blob(['x'], { type: 'image/png' }), 'm.png');
  assert.equal((await call('/vision/translate', { method: 'POST', form: g })).data.found, false);
});

test('free travel phrases', async () => {
  free.setHttp(async (url) => ({ ok: true, json: async () => ({ responseStatus: 200, responseData: { translatedText: 'x' } }) }));
  const r = await call('/travel/hotel?lang=th');
  assert.equal(r.data.phrases.length, 7);
});

test('free engine can be used without OpenAI configured; OpenAI choice is validated', async () => {
  // mock mode counts as "available" in tests, so only the validation shape is checked here
  assert.equal((await call('/me', { method: 'PATCH', body: { engine: 'bogus' } })).status, 400);
});

test('detect endpoint and OCR-only mode (browser does the translating)', async () => {
  const d = await call('/detect', { method: 'POST', body: { text: 'Where is the nearest train station please?' } });
  assert.equal(d.data.source, 'en');
  free.setOcr(async () => 'ผัดไทย กุ้ง');
  const n = calls.length;
  const f = new FormData(); f.append('image', new Blob(['x'], { type: 'image/png' }), 'm.png'); f.append('ocrOnly', '1');
  const v = await call('/vision/translate', { method: 'POST', form: f });
  assert.equal(v.data.found, true); assert.equal(v.data.source, 'th'); assert.equal(v.data.translation, '');
  assert.equal(calls.length, n, 'server must not call the translation service in OCR-only mode');
});
