import './env.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/app.js';
import { openDb } from '../src/db.js';

let server, base, token;
test.before(async () => {
  server = createApp({ db: openDb(':memory:') }).listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

const call = async (path, { method = 'GET', body, form, auth = true } = {}) => {
  const headers = {};
  if (auth && token) headers.Authorization = `Bearer ${token}`;
  if (body) headers['Content-Type'] = 'application/json';
  const res = await fetch(base + path, { method, headers, body: form ?? (body ? JSON.stringify(body) : undefined) });
  const ct = res.headers.get('content-type') || '';
  return { status: res.status, data: ct.includes('json') ? await res.json() : Buffer.from(await res.arrayBuffer()) };
};
const audioForm = (text, fields = {}) => {
  const f = new FormData();
  f.append('audio', new Blob([text]), 'a.webm');
  for (const [k, v] of Object.entries(fields)) f.append(k, v);
  return f;
};

test('auth: register, duplicate, bad login, protected route', async () => {
  assert.equal((await call('/me', { auth: false })).status, 401);
  const r = await call('/auth/register', { method: 'POST', body: { email: 'A@x.com', password: 'password1' }, auth: false });
  assert.equal(r.status, 201); token = r.data.token;
  assert.equal((await call('/auth/register', { method: 'POST', body: { email: 'a@x.com', password: 'password1' }, auth: false })).status, 409);
  assert.equal((await call('/auth/login', { method: 'POST', body: { email: 'a@x.com', password: 'wrongpass1' }, auth: false })).status, 401);
  assert.equal((await call('/auth/register', { method: 'POST', body: { email: 'b@x.com', password: 'short' }, auth: false })).status, 400);
});

test('profile: language preferences persist and validate', async () => {
  const r = await call('/me', { method: 'PATCH', body: { nativeLang: 'hi', preferredLangs: ['th', 'en', 'th'], defaultTarget: 'th', voice: 'nova', historyEnabled: true, onboarded: true, engine: 'openai' } });
  assert.equal(r.data.user.nativeLang, 'hi');
  assert.deepEqual(r.data.user.preferredLangs, ['th', 'en']);
  assert.equal((await call('/me', { method: 'PATCH', body: { nativeLang: 'xx' } })).status, 400);
  assert.equal((await call('/me')).data.user.historyEnabled, true);
  assert.equal((await call('/me')).data.user.engine, 'openai');
});

test('text translation defaults to native language', async () => {
  const r = await call('/translate/text', { method: 'POST', body: { text: 'hello' } });
  assert.equal(r.data.target, 'hi');
  assert.match(r.data.translation, /^\(hi\)/);
});

test('conversation: other speaker is auto-detected and translated to native', async () => {
  const r = await call('/speech/translate', { method: 'POST', form: audioForm('[th] สวัสดี', { speaker: 'other' }) });
  assert.equal(r.status, 200);
  assert.equal(r.data.sourceLang, 'th'); assert.equal(r.data.targetLang, 'hi'); assert.equal(r.data.original, 'สวัสดี');
});

test('conversation: my turn needs partner language, then translates native -> partner', async () => {
  const r1 = await call('/speech/translate', { method: 'POST', form: audioForm('namaste', { speaker: 'me' }) });
  assert.equal(r1.status, 400); assert.equal(r1.data.code, 'partner_language_unknown');
  const r2 = await call('/speech/translate', { method: 'POST', form: audioForm('namaste', { speaker: 'me', partnerLang: 'th' }) });
  assert.equal(r2.data.sourceLang, 'hi'); assert.equal(r2.data.targetLang, 'th');
});

test('manual language correction overrides detection', async () => {
  const r = await call('/speech/translate', { method: 'POST', form: audioForm('[th] hola', { speaker: 'other', sourceLang: 'es' }) });
  assert.equal(r.data.sourceLang, 'es');
});

test('silent audio returns silent:true and live mode works', async () => {
  assert.equal((await call('/speech/translate', { method: 'POST', form: audioForm('x') })).data.silent, true);
  const r = await call('/speech/translate', { method: 'POST', form: audioForm('[th] hello there', { mode: 'live' }) });
  assert.equal(r.data.targetLang, 'hi');
});

test('tts returns audio, vision returns extracted + translated text', async () => {
  const t = await call('/tts', { method: 'POST', body: { text: 'hi', speed: 1.2 } });
  assert.equal(t.status, 200); assert.ok(t.data.length > 0);
  const f = new FormData(); f.append('image', new Blob(['x'], { type: 'image/png' }), 'm.png');
  const v = await call('/vision/translate', { method: 'POST', form: f });
  assert.equal(v.data.found, true); assert.equal(v.data.target, 'hi');
  const g = new FormData(); g.append('image', new Blob(['x'], { type: 'text/plain' }), 'm.txt');
  assert.equal((await call('/vision/translate', { method: 'POST', form: g })).status, 400);
});

test('travel phrases are translated and cached', async () => {
  const a = await call('/travel/airport?lang=th');
  assert.equal(a.data.phrases.length, 7);
  assert.equal((await call('/travel/airport?lang=en')).data.phrases[0], 'Where is the check-in counter?');
  assert.equal((await call('/travel/nope?lang=th')).status, 404);
});

test('history: sessions, entries, bookmarks, delete, isolation, opt-out', async () => {
  const s = await call('/history/sessions', { method: 'POST', body: { mode: 'conversation', sourceLang: 'th', targetLang: 'hi' } });
  assert.equal(s.status, 201);
  const e = await call(`/history/sessions/${s.data.id}/entries`, { method: 'POST', body: { original: 'a', translated: 'b', sourceLang: 'th', targetLang: 'hi' } });
  assert.equal((await call(`/history/entries/${e.data.id}`, { method: 'PATCH', body: { bookmarked: true } })).status, 200);
  assert.equal((await call('/history/bookmarks')).data.entries.length, 1);
  assert.equal((await call(`/history/sessions/${s.data.id}`)).data.entries.length, 1);

  const other = await call('/auth/register', { method: 'POST', body: { email: 'c@x.com', password: 'password1' }, auth: false });
  const mine = token; token = other.data.token;
  assert.equal((await call(`/history/sessions/${s.data.id}`)).status, 404);
  assert.equal((await call('/history/sessions', { method: 'POST', body: { mode: 'live' } })).status, 403); // history off by default
  token = mine;

  assert.equal((await call(`/history/sessions/${s.data.id}`, { method: 'DELETE' })).status, 204);
  assert.equal((await call('/history/sessions')).data.sessions.length, 0);
});

test('phrases: CRUD', async () => {
  const p = await call('/phrases', { method: 'POST', body: { original: 'Thanks', translated: 'ขอบคุณ', folder: 'Polite', targetLang: 'th' } });
  assert.equal((await call('/phrases')).data.phrases.length, 1);
  await call(`/phrases/${p.data.id}`, { method: 'PATCH', body: { folder: 'Food' } });
  assert.equal((await call('/phrases')).data.phrases[0].folder, 'Food');
  await call(`/phrases/${p.data.id}`, { method: 'DELETE' });
  assert.equal((await call('/phrases')).data.phrases.length, 0);
});
