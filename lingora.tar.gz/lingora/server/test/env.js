process.env.NODE_ENV = 'test';
process.env.LINGORA_MOCK_AI = '1';
process.env.JWT_SECRET = 'test-secret';
