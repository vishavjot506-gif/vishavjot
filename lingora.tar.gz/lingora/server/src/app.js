import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { openDb } from './db.js';
import * as agents from './agents/index.js';
import { LANGUAGES, isSupported } from './languages.js';
import { TRAVEL, SCENARIOS } from './travel-data.js';

const openaiAvailable = () => !!config.openaiKey || config.mockAI;
const engineOf = (u) => (u.engine === 'openai' && openaiAvailable() ? 'openai' : 'free');

const VOICES = ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'];
const lang = z.string().refine(isSupported, 'Unsupported language');
const bad = (msg, status = 400) => Object.assign(new Error(msg), { status });
const wrapAsync = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const parse = (schema, data) => {
  const r = schema.safeParse(data);
  if (!r.success) throw bad(r.error.issues.map((i) => `${i.path.join('.') || 'body'}: ${i.message}`).join('; '));
  return r.data;
};

const publicUser = (u) => ({
  id: u.id, email: u.email, name: u.name, nativeLang: u.native_lang,
  preferredLangs: JSON.parse(u.preferred_langs), defaultTarget: u.default_target,
  voice: u.voice, voiceSpeed: u.voice_speed, historyEnabled: !!u.history_enabled, onboarded: !!u.onboarded,
  engine: engineOf(u),
});

export function createApp({ db = openDb() } = {}) {
  const app = express();
  app.set('trust proxy', 1);
  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:'], mediaSrc: ["'self'", 'blob:'], connectSrc: ["'self'", 'https://api.mymemory.translated.net'],
        fontSrc: ["'self'", 'data:'], workerSrc: ["'self'", 'blob:'], objectSrc: ["'none'"], baseUri: ["'self'"], frameAncestors: ["'none'"],
      },
    },
    // The browser tab must be allowed to use the microphone.
    permissionsPolicy: undefined,
  }));
  app.use((_req, res, next) => { res.setHeader('Permissions-Policy', 'microphone=(self), camera=(self)'); next(); });
  app.use(cors({ origin: config.corsOrigin === '*' ? true : config.corsOrigin.split(',') }));
  app.use(express.json({ limit: '1mb' }));

  // Audio/images are processed in memory and never written to disk or the database.
  const audioUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 12 * 1024 * 1024 } }).single('audio');
  const imageUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } }).single('image');

  const authLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 30, standardHeaders: true, legacyHeaders: false });
  const aiLimiter = rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false });

  const sign = (u) => jwt.sign({ sub: u.id }, config.jwtSecret, { expiresIn: '30d' });
  const auth = (req, _res, next) => {
    try {
      const token = (req.headers.authorization || '').replace(/^Bearer /, '');
      const { sub } = jwt.verify(token, config.jwtSecret);
      const user = db.prepare('SELECT * FROM users WHERE id = ?').get(sub);
      if (!user) throw new Error('no user');
      req.user = user;
      next();
    } catch { next(bad('Unauthorized', 401)); }
  };

  app.get('/health', (_req, res) => res.json({ ok: true, openaiAvailable: openaiAvailable() }));
  app.get('/engines', (_req, res) => res.json({ openaiAvailable: openaiAvailable(), agents: agents.AGENTS, freeTranslator: config.libreUrl ? 'LibreTranslate' : 'MyMemory' }));
  app.get('/languages', (_req, res) => res.json({ languages: LANGUAGES, voices: VOICES, scenarios: SCENARIOS }));

  // ---------- auth & profile ----------
  const creds = z.object({ email: z.string().email().max(200).transform((s) => s.toLowerCase()), password: z.string().min(8).max(200) });
  app.post('/auth/register', authLimiter, wrapAsync(async (req, res) => {
    const { email, password } = parse(creds.extend({ name: z.string().max(100).optional() }), req.body);
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) throw bad('Email already registered', 409);
    const hash = await bcrypt.hash(password, 11);
    const r = db.prepare('INSERT INTO users (email, password_hash, name) VALUES (?,?,?)').run(email, hash, req.body.name || '');
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(r.lastInsertRowid);
    res.status(201).json({ token: sign(user), user: publicUser(user) });
  }));
  app.post('/auth/login', authLimiter, wrapAsync(async (req, res) => {
    const { email, password } = parse(creds, req.body);
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) throw bad('Invalid email or password', 401);
    res.json({ token: sign(user), user: publicUser(user) });
  }));

  app.get('/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));
  app.patch('/me', auth, (req, res) => {
    const p = parse(z.object({
      name: z.string().max(100), nativeLang: lang, preferredLangs: z.array(lang).max(20),
      defaultTarget: lang, voice: z.enum(VOICES), voiceSpeed: z.number().min(0.5).max(1.5),
      historyEnabled: z.boolean(), onboarded: z.boolean(), engine: z.enum(['free', 'openai']),
    }).partial(), req.body);
    if (p.engine === 'openai' && !openaiAvailable()) throw bad('OpenAI is not set up on this server. Add OPENAI_API_KEY to server/.env and restart.');
    const map = { name: 'name', engine: 'engine', nativeLang: 'native_lang', defaultTarget: 'default_target', voice: 'voice', voiceSpeed: 'voice_speed' };
    const sets = []; const vals = [];
    for (const [k, col] of Object.entries(map)) if (p[k] !== undefined) { sets.push(`${col} = ?`); vals.push(p[k]); }
    if (p.preferredLangs) { sets.push('preferred_langs = ?'); vals.push(JSON.stringify([...new Set(p.preferredLangs)])); }
    if (p.historyEnabled !== undefined) { sets.push('history_enabled = ?'); vals.push(p.historyEnabled ? 1 : 0); }
    if (p.onboarded !== undefined) { sets.push('onboarded = ?'); vals.push(p.onboarded ? 1 : 0); }
    if (sets.length) db.prepare(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`).run(...vals, req.user.id);
    res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
  });
  app.delete('/me', auth, (req, res) => { db.prepare('DELETE FROM users WHERE id = ?').run(req.user.id); res.status(204).end(); });

  // ---------- translation ----------
  // Offline language detection (free, no quota). Lets the browser translate directly with the right source language.
  app.post('/detect', auth, (req, res) => {
    const { text } = parse(z.object({ text: z.string().trim().min(1).max(5000) }), req.body);
    res.json({ source: agents.detector.run({ text }) });
  });

  const textBody = z.object({ text: z.string().trim().min(1).max(5000), target: lang.optional(), source: lang.optional(), note: z.boolean().optional() });
  app.post('/translate/text', auth, aiLimiter, wrapAsync(async (req, res) => {
    const b = parse(textBody, req.body);
    const target = b.target || req.user.native_lang;
    res.json({ ...(await agents.translator.run({ engine: engineOf(req.user), text: b.text, target, source: b.source, note: b.note })), target });
  }));

  /**
   * One spoken segment -> transcript + translation.
   * mode=turn   speaker=me|other (two-way conversation, shared-device turn-taking)
   * mode=live   always translates into the user's native language
   */
  const speechFields = z.object({
    mode: z.enum(['turn', 'live']).default('turn'),
    speaker: z.enum(['me', 'other']).default('other'),
    partnerLang: lang.optional().or(z.literal('')),
    sourceLang: lang.optional().or(z.literal('')),   // manual correction of detection
    context: z.string().max(500).optional(),
    note: z.enum(['0', '1']).optional(),
  });
  app.post('/speech/translate', auth, aiLimiter, audioUpload, wrapAsync(async (req, res) => {
    if (!req.file) throw bad('audio file is required');
    const f = parse(speechFields, req.body);
    const native = req.user.native_lang;
    const forced = f.sourceLang || undefined;
    const partner = f.partnerLang || undefined;
    const iAmSpeaking = f.mode === 'turn' && f.speaker === 'me';

    if (iAmSpeaking && !partner) throw Object.assign(bad('Choose the other person\'s language first'), { code: 'partner_language_unknown' });
    // Hint Whisper with the known language of the speaker: improves accuracy a lot on short clips.
    const hint = forced ?? (iAmSpeaking ? native : undefined);
    const out = await agents.speechToTranslation({
      engine: engineOf(req.user), audio: req.file, forced, hint, target: iAmSpeaking ? partner : native,
      expectedSource: iAmSpeaking ? native : undefined, context: f.context, note: f.note === '1',
    });
    if (out.silent) return res.json({ silent: true });
    res.json({ ...out, speaker: f.speaker, targetLang: iAmSpeaking ? partner : native });
  }));

  app.post('/tts', auth, aiLimiter, wrapAsync(async (req, res) => {
    const b = parse(z.object({ text: z.string().trim().min(1).max(4000), voice: z.enum(VOICES).optional(), speed: z.number().min(0.5).max(1.5).optional() }), req.body);
    const audio = await agents.voice.run({ engine: engineOf(req.user), text: b.text, voice: b.voice || req.user.voice, speed: b.speed ?? req.user.voice_speed });
    res.type('audio/mpeg').send(audio);
  }));

  app.post('/vision/translate', auth, aiLimiter, imageUpload, wrapAsync(async (req, res) => {
    if (!req.file) throw bad('image file is required');
    if (!/^image\/(jpeg|png|webp|gif)$/.test(req.file.mimetype)) throw bad('Unsupported image type');
    const b = parse(z.object({ target: lang.optional().or(z.literal('')), sourceLang: lang.optional().or(z.literal('')), ocrOnly: z.enum(['0', '1']).optional() }), req.body);
    const target = b.target || req.user.native_lang;
    const hintLangs = [...new Set([b.sourceLang, ...JSON.parse(req.user.preferred_langs), req.user.native_lang].filter(Boolean))];
    res.json({ ...(await agents.vision.run({ engine: engineOf(req.user), buffer: req.file.buffer, mimetype: req.file.mimetype, target, hintLangs, ocrOnly: b.ocrOnly === '1' })), target });
  }));

  // ---------- travel ----------
  app.get('/travel/:scenario', auth, aiLimiter, wrapAsync(async (req, res) => {
    const { scenario } = req.params;
    const l = parse(z.object({ lang }), { lang: req.query.lang }).lang;
    if (!TRAVEL[scenario]) throw bad('Unknown scenario', 404);
    let row = db.prepare('SELECT phrases FROM travel_cache WHERE scenario = ? AND lang = ?').get(scenario, l);
    let list;
    if (row) list = JSON.parse(row.phrases);
    else {
      list = await agents.phrases.run({ engine: engineOf(req.user), scenario, lang: l });
      db.prepare('INSERT OR REPLACE INTO travel_cache (scenario, lang, phrases) VALUES (?,?,?)').run(scenario, l, JSON.stringify(list));
    }
    res.json({ scenario, lang: l, phrases: list });
  }));

  // ---------- history ----------
  const owns = (sid, uid) => !!db.prepare('SELECT 1 FROM sessions WHERE id = ? AND user_id = ?').get(sid, uid);
  app.post('/history/sessions', auth, (req, res) => {
    if (!req.user.history_enabled) throw bad('History is turned off', 403);
    const b = parse(z.object({ mode: z.enum(['conversation', 'live', 'text', 'camera']), sourceLang: lang.optional(), targetLang: lang.optional() }), req.body);
    const r = db.prepare('INSERT INTO sessions (user_id, mode, source_lang, target_lang) VALUES (?,?,?,?)').run(req.user.id, b.mode, b.sourceLang ?? null, b.targetLang ?? null);
    res.status(201).json({ id: Number(r.lastInsertRowid) });
  });
  app.post('/history/sessions/:id/entries', auth, (req, res) => {
    const sid = Number(req.params.id);
    if (!owns(sid, req.user.id)) throw bad('Not found', 404);
    const b = parse(z.object({
      speaker: z.enum(['me', 'other']).default('other'), original: z.string().min(1).max(5000), translated: z.string().min(1).max(5000),
      sourceLang: lang.optional(), targetLang: lang.optional(),
    }), req.body);
    const r = db.prepare('INSERT INTO entries (session_id, speaker, original, translated, source_lang, target_lang) VALUES (?,?,?,?,?,?)')
      .run(sid, b.speaker, b.original, b.translated, b.sourceLang ?? null, b.targetLang ?? null);
    // Keep the session's language pair current (e.g. after manual correction).
    if (b.sourceLang || b.targetLang) db.prepare('UPDATE sessions SET source_lang = COALESCE(?, source_lang), target_lang = COALESCE(?, target_lang) WHERE id = ?').run(b.sourceLang ?? null, b.targetLang ?? null, sid);
    res.status(201).json({ id: Number(r.lastInsertRowid) });
  });
  app.get('/history/sessions', auth, (req, res) => {
    const sessions = db.prepare(`SELECT s.*, (SELECT COUNT(*) FROM entries e WHERE e.session_id = s.id) AS entry_count
      FROM sessions s WHERE s.user_id = ? ORDER BY s.created_at DESC, s.id DESC LIMIT 200`).all(req.user.id);
    res.json({ sessions });
  });
  app.get('/history/sessions/:id', auth, (req, res) => {
    const s = db.prepare('SELECT * FROM sessions WHERE id = ? AND user_id = ?').get(Number(req.params.id), req.user.id);
    if (!s) throw bad('Not found', 404);
    res.json({ session: s, entries: db.prepare('SELECT * FROM entries WHERE session_id = ? ORDER BY id').all(s.id) });
  });
  app.delete('/history/sessions/:id', auth, (req, res) => {
    db.prepare('DELETE FROM sessions WHERE id = ? AND user_id = ?').run(Number(req.params.id), req.user.id);
    res.status(204).end();
  });
  app.delete('/history', auth, (req, res) => { db.prepare('DELETE FROM sessions WHERE user_id = ?').run(req.user.id); res.status(204).end(); });
  app.patch('/history/entries/:id', auth, (req, res) => {
    const b = parse(z.object({ bookmarked: z.boolean() }), req.body);
    const r = db.prepare(`UPDATE entries SET bookmarked = ? WHERE id = ? AND session_id IN (SELECT id FROM sessions WHERE user_id = ?)`).run(b.bookmarked ? 1 : 0, Number(req.params.id), req.user.id);
    if (!r.changes) throw bad('Not found', 404);
    res.json({ ok: true });
  });
  app.get('/history/bookmarks', auth, (req, res) => {
    res.json({ entries: db.prepare(`SELECT e.* FROM entries e JOIN sessions s ON s.id = e.session_id WHERE s.user_id = ? AND e.bookmarked = 1 ORDER BY e.id DESC LIMIT 500`).all(req.user.id) });
  });

  // ---------- saved phrases ----------
  const phraseBody = z.object({ folder: z.string().trim().min(1).max(60).default('General'), original: z.string().min(1).max(2000), translated: z.string().min(1).max(2000), sourceLang: lang.optional(), targetLang: lang.optional() });
  app.get('/phrases', auth, (req, res) => res.json({ phrases: db.prepare('SELECT * FROM phrases WHERE user_id = ? ORDER BY folder, id DESC').all(req.user.id) }));
  app.post('/phrases', auth, (req, res) => {
    const b = parse(phraseBody, req.body);
    const r = db.prepare('INSERT INTO phrases (user_id, folder, original, translated, source_lang, target_lang) VALUES (?,?,?,?,?,?)')
      .run(req.user.id, b.folder, b.original, b.translated, b.sourceLang ?? null, b.targetLang ?? null);
    res.status(201).json({ id: Number(r.lastInsertRowid) });
  });
  app.patch('/phrases/:id', auth, (req, res) => {
    const b = parse(z.object({ folder: z.string().trim().min(1).max(60) }), req.body);
    const r = db.prepare('UPDATE phrases SET folder = ? WHERE id = ? AND user_id = ?').run(b.folder, Number(req.params.id), req.user.id);
    if (!r.changes) throw bad('Not found', 404);
    res.json({ ok: true });
  });
  app.delete('/phrases/:id', auth, (req, res) => { db.prepare('DELETE FROM phrases WHERE id = ? AND user_id = ?').run(Number(req.params.id), req.user.id); res.status(204).end(); });

  // ---------- web app (single-service hosting) ----------
  // If the Expo web build exists, serve it from the same origin as the API.
  const webDir = process.env.WEB_DIR || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../app/dist');
  if (fs.existsSync(path.join(webDir, 'index.html'))) {
    app.use(express.static(webDir, { index: false, maxAge: '1h' }));
    app.get(/^\/(?!_expo).*/, (req, res, next) => (req.accepts('html') && !req.path.includes('.') ? res.sendFile(path.join(webDir, 'index.html')) : next()));
  }

  // ---------- errors ----------
  app.use((_req, _res, next) => next(bad('Not found', 404)));
  app.use((err, _req, res, _next) => {
    if (err instanceof multer.MulterError) return res.status(413).json({ error: err.message });
    const status = err.status || 500;
    if (status >= 500) console.error('[lingora]', err);
    res.status(status).json({ error: status >= 500 && !err.status ? 'Internal error' : err.message, ...(err.code ? { code: err.code } : {}) });
  });
  return app;
}
