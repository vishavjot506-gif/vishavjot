import { createApp } from './app.js';
import { config } from './config.js';

if (!config.openaiKey && !config.mockAI) console.log('[lingora] No OPENAI_API_KEY: running in free mode only (OpenAI option hidden).');
createApp().listen(config.port, () => console.log(`Lingora API listening on :${config.port}`));
