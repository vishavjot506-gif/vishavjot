import 'dotenv/config';
import crypto from 'node:crypto';

const isTest = process.env.NODE_ENV === 'test';
let jwtSecret = process.env.JWT_SECRET;
if (!jwtSecret) {
  if (process.env.NODE_ENV === 'production') throw new Error('JWT_SECRET is required in production');
  jwtSecret = crypto.randomBytes(32).toString('hex');
  if (!isTest) console.warn('[lingora] JWT_SECRET not set: using a random one (sessions reset on restart).');
}

export const config = {
  port: Number(process.env.PORT || 4000),
  jwtSecret,
  dbPath: process.env.DB_PATH || './lingora.db',
  corsOrigin: process.env.CORS_ORIGIN || '*',
  openaiKey: process.env.OPENAI_API_KEY,
  // Optional free-engine settings
  libreUrl: process.env.LIBRETRANSLATE_URL || '',
  libreKey: process.env.LIBRETRANSLATE_KEY || '',
  myMemoryEmail: process.env.MYMEMORY_EMAIL || '',
  // Dev/test only: canned AI responses, no network. Never enable in production.
  mockAI: process.env.LINGORA_MOCK_AI === '1',
  models: {
    stt: process.env.STT_MODEL || 'whisper-1',
    text: process.env.TEXT_MODEL || 'gpt-4o-mini',
    vision: process.env.VISION_MODEL || 'gpt-4o-mini',
    tts: process.env.TTS_MODEL || 'tts-1',
  },
};
