import { DatabaseSync } from 'node:sqlite';
import { config } from './config.js';

export function openDb(path = config.dbPath) {
  const db = new DatabaseSync(path);
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL DEFAULT '',
      native_lang TEXT NOT NULL DEFAULT 'en',
      preferred_langs TEXT NOT NULL DEFAULT '[]',
      default_target TEXT NOT NULL DEFAULT 'en',
      voice TEXT NOT NULL DEFAULT 'nova',
      voice_speed REAL NOT NULL DEFAULT 1.0,
      history_enabled INTEGER NOT NULL DEFAULT 0,
      onboarded INTEGER NOT NULL DEFAULT 0,
      engine TEXT NOT NULL DEFAULT 'free',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      mode TEXT NOT NULL,
      source_lang TEXT,
      target_lang TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
      speaker TEXT NOT NULL DEFAULT 'other',
      original TEXT NOT NULL,
      translated TEXT NOT NULL,
      source_lang TEXT,
      target_lang TEXT,
      bookmarked INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS phrases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      folder TEXT NOT NULL DEFAULT 'General',
      original TEXT NOT NULL,
      translated TEXT NOT NULL,
      source_lang TEXT,
      target_lang TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS travel_cache (
      scenario TEXT NOT NULL,
      lang TEXT NOT NULL,
      phrases TEXT NOT NULL,
      PRIMARY KEY (scenario, lang)
    );
  `);
  // Migration for databases created before the engine column existed.
  if (!db.prepare('PRAGMA table_info(users)').all().some((c) => c.name === 'engine'))
    db.exec("ALTER TABLE users ADD COLUMN engine TEXT NOT NULL DEFAULT 'free'");
  return db;
}
