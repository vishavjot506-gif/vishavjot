import OpenAI from 'openai';
import { config } from './config.js';
import { codeFromName, languageName, isSupported, LANGUAGES } from './languages.js';

let client;
const openai = () => (client ??= new OpenAI({ apiKey: config.openaiKey }));

export class AIError extends Error {
  constructor(message, status = 502) { super(message); this.status = status; }
}
const ensureKey = () => {
  if (!config.openaiKey) throw new AIError('OPENAI_API_KEY is not configured on the server', 503);
};

const langList = LANGUAGES.map((l) => `${l.code}=${l.name}`).join(', ');

/** Speech -> text. Returns { text, language (code|null), silent }. */
export async function transcribe({ buffer, filename, mimetype, language }) {
  if (config.mockAI) return mock.transcribe(buffer, language);
  ensureKey();
  const file = await OpenAI.toFile(buffer, filename || 'audio.webm', { type: mimetype || 'audio/webm' });
  try {
    const res = await openai().audio.transcriptions.create({
      file, model: config.models.stt, response_format: 'verbose_json',
      ...(language && isSupported(language) ? { language } : {}),
    });
    const segs = res.segments ?? [];
    // Whisper hallucinates text ("Thanks for watching") on silence. Treat clearly non-speech as silent.
    const silent = !res.text?.trim() || (segs.length > 0 && segs.every((s) => s.no_speech_prob > 0.6));
    return { text: silent ? '' : res.text.trim(), language: codeFromName(res.language) ?? language ?? null, silent };
  } catch (e) { throw wrap(e); }
}

/** Text -> translation. Detects source language when `source` is not given. */
export async function translate({ text, target, source, context, note = false }) {
  if (config.mockAI) return mock.translate(text, target, source);
  ensureKey();
  const sys =
    `You are a precise interpreter. Translate the user's text into ${languageName(target)} (${target}). ` +
    `Preserve meaning, tone and register; do not add or omit content; keep names. ` +
    (source ? `The source language is ${languageName(source)}. ` : `Detect the source language. `) +
    `Supported language codes: ${langList}. If the source is not in the list, use the closest ISO 639-1 code. ` +
    (note ? `Also add "note": a one-sentence cultural or idiom explanation ONLY if the text contains an idiom, honorific or culture-specific expression, else empty string. ` : '') +
    `Reply with JSON only: {"source":"<code>","translation":"<text>"${note ? ',"note":"<text>"' : ''}}.`;
  const user = context ? `Previous sentence (context only, do not translate): ${context}\n\nTranslate:\n${text}` : text;
  const out = await chatJson(sys, user);
  return { source: String(out.source || source || 'en').toLowerCase().slice(0, 2), translation: String(out.translation ?? ''), note: out.note || '' };
}

/** Translate a list of English phrases (used by the travel assistant). */
export async function translateBatch({ items, target }) {
  if (config.mockAI) return items.map((t) => `[${target}] ${t}`);
  ensureKey();
  const out = await chatJson(
    `Translate each English phrase into natural, polite ${languageName(target)} as a traveller would say it. ` +
    `Reply with JSON only: {"items":["..."]} with exactly ${items.length} strings in the same order.`,
    JSON.stringify(items));
  if (!Array.isArray(out.items) || out.items.length !== items.length) throw new AIError('Batch translation returned unexpected shape');
  return out.items.map(String);
}

/** Image -> extracted text + translation. */
export async function translateImage({ buffer, mimetype, target }) {
  if (config.mockAI) return mock.image(target);
  ensureKey();
  const url = `data:${mimetype};base64,${buffer.toString('base64')}`;
  try {
    const res = await openai().chat.completions.create({
      model: config.models.vision, response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content:
          `You read text in photos (menus, signs, notices, documents). Extract ALL legible text faithfully in reading order, ` +
          `then translate it into ${languageName(target)}. Do not invent text that is not visible. ` +
          `If no text is legible set "found":false. Reply JSON only: {"found":bool,"source":"<code>","extracted":"<text>","translation":"<text>"}` },
        { role: 'user', content: [{ type: 'image_url', image_url: { url } }] },
      ],
    });
    const o = JSON.parse(res.choices[0].message.content || '{}');
    return { found: !!o.found, source: String(o.source || '').toLowerCase().slice(0, 2), extracted: o.extracted || '', translation: o.translation || '' };
  } catch (e) { throw wrap(e); }
}

/** Text -> speech (mp3 Buffer). */
export async function speak({ text, voice, speed }) {
  if (config.mockAI) return mock.tts();
  ensureKey();
  try {
    const res = await openai().audio.speech.create({
      model: config.models.tts, voice, input: text.slice(0, 4000), speed, response_format: 'mp3',
    });
    return Buffer.from(await res.arrayBuffer());
  } catch (e) { throw wrap(e); }
}

async function chatJson(system, user) {
  try {
    const res = await openai().chat.completions.create({
      model: config.models.text, temperature: 0.2, response_format: { type: 'json_object' },
      messages: [{ role: 'system', content: system }, { role: 'user', content: user }],
    });
    return JSON.parse(res.choices[0].message.content || '{}');
  } catch (e) { throw wrap(e); }
}
function wrap(e) {
  if (e instanceof AIError) return e;
  const status = e?.status === 429 ? 429 : 502;
  return new AIError(status === 429 ? 'AI provider rate limit reached, try again shortly' : `AI provider error: ${e?.message ?? e}`, status);
}

// ---- Deterministic fakes for tests / keyless local UI development only ----
const mock = {
  transcribe(buffer, language) {
    if (buffer.length < 3) return { text: '', language: null, silent: true };
    const text = buffer.toString('utf8').slice(0, 200);
    const m = text.match(/^\[(\w\w)\]/);
    return { text: text.replace(/^\[\w\w\]\s*/, ''), language: language || (m && m[1]) || 'th', silent: false };
  },
  translate(text, target, source) {
    return { source: source || 'th', translation: `(${target}) ${text}`, note: '' };
  },
  image: (target) => ({ found: true, source: 'th', extracted: 'ผัดไทย', translation: `(${target}) Pad Thai` }),
  tts: () => Buffer.from('ID3mock-mp3'),
};
