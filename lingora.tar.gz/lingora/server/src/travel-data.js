// English source phrases per scenario; translated on demand and cached.
export const TRAVEL = {
  airport: ['Where is the check-in counter?', 'Where is gate number 12?', 'My luggage is missing.', 'Where can I exchange money?', 'Is this the line for immigration?', 'I have a connecting flight.', 'Where is the nearest restroom?'],
  hotel: ['I have a reservation under my name.', 'What time is check-out?', 'Could I have an extra towel?', 'Is breakfast included?', 'The air conditioning is not working.', 'Could you call me a taxi?', 'Can I leave my luggage here?'],
  restaurant: ['A table for two, please.', 'Can I see the menu?', 'I am allergic to peanuts.', 'What do you recommend?', 'Not spicy, please.', 'Could we have the bill, please?', 'Is this vegetarian?'],
  shopping: ['How much is this?', 'Do you have a smaller size?', 'Can you give me a discount?', 'Can I try this on?', 'Do you accept credit cards?', 'I am just looking, thank you.', 'Could I have a bag, please?'],
  taxi: ['Please take me to this address.', 'Could you use the meter?', 'How long will it take?', 'Please stop here.', 'How much to the airport?', 'Could you open the trunk?', 'Please slow down.'],
  directions: ['Where is the nearest train station?', 'How do I get to this place?', 'Is it far from here?', 'Could you show me on the map?', 'Turn left or right?', 'Can I walk there?', 'Could you repeat that, please?'],
  emergency: ['I need help!', 'Please call the police.', 'Please call an ambulance.', 'I need a doctor.', 'I have lost my passport.', 'Where is the nearest hospital?', 'I do not feel well.'],
};
export const SCENARIOS = Object.keys(TRAVEL);
