// Supported languages. `whisper` is the English name Whisper returns for detection.
export const LANGUAGES = [
  ['en', 'English', 'English'], ['hi', 'Hindi', 'हिन्दी'], ['th', 'Thai', 'ไทย'],
  ['ja', 'Japanese', '日本語'], ['ko', 'Korean', '한국어'], ['zh', 'Chinese', '中文'],
  ['es', 'Spanish', 'Español'], ['fr', 'French', 'Français'], ['de', 'German', 'Deutsch'],
  ['it', 'Italian', 'Italiano'], ['pt', 'Portuguese', 'Português'], ['ru', 'Russian', 'Русский'],
  ['ar', 'Arabic', 'العربية'], ['bn', 'Bengali', 'বাংলা'], ['ta', 'Tamil', 'தமிழ்'],
  ['te', 'Telugu', 'తెలుగు'], ['mr', 'Marathi', 'मराठी'], ['gu', 'Gujarati', 'ગુજરાતી'],
  ['kn', 'Kannada', 'ಕನ್ನಡ'], ['ml', 'Malayalam', 'മലയാളം'], ['ur', 'Urdu', 'اردو'],
  ['ne', 'Nepali', 'नेपाली'], ['id', 'Indonesian', 'Bahasa Indonesia'], ['ms', 'Malay', 'Bahasa Melayu'],
  ['vi', 'Vietnamese', 'Tiếng Việt'], ['tl', 'Tagalog', 'Tagalog'], ['tr', 'Turkish', 'Türkçe'],
  ['fa', 'Persian', 'فارسی'], ['he', 'Hebrew', 'עברית'], ['nl', 'Dutch', 'Nederlands'],
  ['pl', 'Polish', 'Polski'], ['sv', 'Swedish', 'Svenska'], ['el', 'Greek', 'Ελληνικά'],
  ['uk', 'Ukrainian', 'Українська'], ['cs', 'Czech', 'Čeština'], ['ro', 'Romanian', 'Română'],
  ['sw', 'Swahili', 'Kiswahili'],
].map(([code, name, native]) => ({ code, name, native }));

const byCode = new Map(LANGUAGES.map((l) => [l.code, l]));
const byName = new Map(LANGUAGES.map((l) => [l.name.toLowerCase(), l]));

export const isSupported = (code) => byCode.has(code);
export const languageName = (code) => byCode.get(code)?.name ?? code;
/** Whisper returns names like "thai"; map to our code or null. */
export const codeFromName = (name) => byName.get(String(name || '').toLowerCase())?.code ?? null;
