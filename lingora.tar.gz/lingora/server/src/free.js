// Free engines: no paid API. Network calls go through `http` so tests can replace it.
import { franc } from 'franc-min';
import { config } from './config.js';
import { languageName, isSupported } from './languages.js';

export class FreeEngineError extends Error { constructor(m, status = 400) { super(m); this.status = status; } }

let http = (...a) => fetch(...a);
export const setHttp = (fn) => { http = fn; };

// ---------- language detection (offline) ----------
const FRANC = { eng: 'en', hin: 'hi', tha: 'th', jpn: 'ja', kor: 'ko', cmn: 'zh', spa: 'es', fra: 'fr', deu: 'de', ita: 'it', por: 'pt', rus: 'ru',
  arb: 'ar', ben: 'bn', tam: 'ta', tel: 'te', mar: 'mr', guj: 'gu', kan: 'kn', mal: 'ml', urd: 'ur', npi: 'ne', ind: 'id', zlm: 'ms', zsm: 'ms',
  vie: 'vi', tgl: 'tl', tur: 'tr', pes: 'fa', heb: 'he', nld: 'nl', pol: 'pl', swe: 'sv', ell: 'el', ukr: 'uk', ces: 'cs', ron: 'ro', swh: 'sw' };
// Script-based fallback for short text, where statistical detection is unreliable.
const SCRIPTS = [[/[\u0E00-\u0E7F]/, 'th'], [/[\u3040-\u30FF]/, 'ja'], [/[\uAC00-\uD7AF]/, 'ko'], [/[\u0980-\u09FF]/, 'bn'], [/[\u0B80-\u0BFF]/, 'ta'],
  [/[\u0C00-\u0C7F]/, 'te'], [/[\u0A80-\u0AFF]/, 'gu'], [/[\u0C80-\u0CFF]/, 'kn'], [/[\u0D00-\u0D7F]/, 'ml'], [/[\u0590-\u05FF]/, 'he'],
  [/[\u0370-\u03FF]/, 'el'], [/[\u0900-\u097F]/, 'hi'], [/[\u4E00-\u9FFF]/, 'zh']];
export function detectLanguage(text) {
  const guess = FRANC[franc(text, { minLength: 3 })];
  const script = SCRIPTS.find(([re]) => re.test(text))?.[1];
  // Devanagari: franc often returns Maithili/Bhojpuri etc. for Hindi; only trust Marathi/Nepali when franc says so.
  if (script === 'hi') return guess === 'mr' || guess === 'ne' ? guess : 'hi';
  if (guess && isSupported(guess)) return guess;
  return script || null;
}

// ---------- translation ----------
const MM = { zh: 'zh-CN' };
const mm = (c) => MM[c] || c;

/** MyMemory accepts at most 500 bytes per request, so split on sentence boundaries. */
export function chunkText(text, maxBytes = 450) {
  const parts = text.match(/[^.!?。！？\n]+[.!?。！？]*\s*/g) || [text];
  const out = []; let cur = '';
  const push = () => { if (cur.trim()) out.push(cur); cur = ''; };
  for (const p of parts) {
    if (Buffer.byteLength(cur + p) > maxBytes) push();
    if (Buffer.byteLength(p) > maxBytes) { // one very long sentence: hard split on characters
      for (const ch of p) { if (Buffer.byteLength(cur + ch) > maxBytes) push(); cur += ch; }
    } else cur += p;
  }
  push();
  return out;
}

async function libre(text, target, source) {
  const res = await http(`${config.libreUrl.replace(/\/$/, '')}/translate`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ q: text, source: source || 'auto', target, format: 'text', ...(config.libreKey ? { api_key: config.libreKey } : {}) }),
  });
  if (!res.ok) throw new FreeEngineError(`LibreTranslate error ${res.status}`, 502);
  const j = await res.json();
  return { translation: j.translatedText, source: source || j.detectedLanguage?.language };
}

async function myMemory(text, target, source) {
  const pieces = [];
  for (const q of chunkText(text)) {
    const url = new URL('https://api.mymemory.translated.net/get');
    url.searchParams.set('q', q);
    url.searchParams.set('langpair', `${source ? mm(source) : 'Autodetect'}|${mm(target)}`);
    if (config.myMemoryEmail) url.searchParams.set('de', config.myMemoryEmail);
    const res = await http(url);
    if (!res.ok) throw new FreeEngineError(`Free translation service error ${res.status}`, 502);
    const j = await res.json();
    if (String(j.responseStatus) === '429' || j.quotaFinished)
      throw new FreeEngineError('Free translation limit reached for today. Try again tomorrow, set MYMEMORY_EMAIL in .env for a higher limit, or switch to OpenAI in Settings.', 429);
    if (String(j.responseStatus) !== '200') throw new FreeEngineError(`Free translation failed: ${j.responseDetails || j.responseStatus}`, 502);
    pieces.push(j.responseData.translatedText);
  }
  return { translation: pieces.join(' ').replace(/\s+/g, ' ').trim(), source };
}

export async function translate({ text, target, source }) {
  const src = source || detectLanguage(text) || undefined;
  if (src === target) return { source: src, translation: text, note: '' };
  const r = config.libreUrl ? await libre(text, target, src) : await myMemory(text, target, src);
  return { source: r.source || src || 'en', translation: r.translation, note: '' };
}

export async function translateBatch({ items, target }) {
  const out = [];
  for (const it of items) out.push((await translate({ text: it, target, source: 'en' })).translation);
  return out;
}

// ---------- OCR (Tesseract, runs on the server, free) ----------
const TESS = { en: 'eng', hi: 'hin', th: 'tha', ja: 'jpn', ko: 'kor', zh: 'chi_sim', es: 'spa', fr: 'fra', de: 'deu', it: 'ita', pt: 'por', ru: 'rus', ar: 'ara',
  bn: 'ben', ta: 'tam', te: 'tel', mr: 'mar', gu: 'guj', kn: 'kan', ml: 'mal', ur: 'urd', ne: 'nep', id: 'ind', ms: 'msa', vi: 'vie', tl: 'tgl', tr: 'tur',
  fa: 'fas', he: 'heb', nl: 'nld', pl: 'pol', sv: 'swe', el: 'ell', uk: 'ukr', cs: 'ces', ro: 'ron', sw: 'swa' };

let ocrImpl = async (buffer, langs) => {
  const { createWorker } = await import('tesseract.js');
  const worker = await createWorker(langs.join('+'));
  try { return (await worker.recognize(buffer)).data.text; } finally { await worker.terminate(); }
};
export const setOcr = (fn) => { ocrImpl = fn; };

export async function ocr({ buffer, hintLangs }) {
  const langs = [...new Set(hintLangs.map((c) => TESS[c]).filter(Boolean))].slice(0, 4);
  if (!langs.includes('eng')) langs.push('eng');
  try { return (await ocrImpl(buffer, langs)).replace(/[ \t]+\n/g, '\n').trim(); }
  catch (e) { throw new FreeEngineError(`Free text reading failed (${e.message}). The first use of a language downloads its data, so check the internet connection.`, 502); }
}
export { languageName };
