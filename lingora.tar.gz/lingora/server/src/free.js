// Free engines: no paid API. Network calls go through `http` so tests can replace it.
import { franc } from 'franc-min';
import { config } from './config.js';
import { languageName, isSupported } from './languages.js';

export class FreeEngineError extends Error { constructor(m, status = 400) { super(m); this.status = status; } }

let http = (...a) => fetch(...a);
export const setHttp = (fn) => { http = fn; };

// ---------- language detection (offline) ----------
const FRANC = { eng: 'en', hin: 'hi', tha: 'th', jpn: 'ja', kor: 'ko', cmn: 'zh', spa: 'es', fra: 'fr', deu: 'de', ita: 'it', por: 'pt', rus: 'ru',
  arb: 'ar', ben: 'bn', tam: 'ta', tel: 'te', mar: 'mr', guj: 'gu', kan: 'kn', mal: 'ml', urd: 'ur', npi: 'ne', ind: 'id', zlm: 'ms', zsm: 'ms',
  vie: 'vi', tgl: 'tl', tur: 'tr', pes: 'fa', heb: 'he', nld: 'nl', pol: 'pl', swe: 'sv', ell: 'el', ukr: 'uk', ces: 'cs', ron: 'ro', swh: 'sw' };
// Script-based fallback for short text, where statistical detection is unreliable.
const SCRIPTS = [[/[\u0E00-\u0E7F]/, 'th'], [/[\u3040-\u30FF]/, 'ja'], [/[\uAC00-\uD7AF]/, 'ko'], [/[\u0980-\u09FF]/, 'bn'], [/[\u0B80-\u0BFF]/, 'ta'],
  [/[\u0C00-\u0C7F]/, 'te'], [/[\u0A80-\u0AFF]/, 'gu'], [/[\u0C80-\u0CFF]/, 'kn'], [/[\u0D00-\u0D7F]/, 'ml'], [/[\u0590-\u05FF]/, 'he'],
  [/[\u0370-\u03FF]/, 'el'], [/[\u0900-\u097F]/, 'hi'], [/[\u4E00-\u9FFF]/, 'zh']];
export function detectLanguage(text) {
  const guess = FRANC[franc(text, { minLength: 3 })];
  const script = SCRIPTS.find(([re]) => re.test(text))?.[1];
  // Devanagari: franc often returns Maithili/Bhojpuri etc. for Hindi; only trust Marathi/Nepali when franc says so.
  if (script === 'hi') return guess === 'mr' || guess === 'ne' ? guess : 'hi';
  if (guess && isSupported(guess)) return guess;
  return script || null;
}

// ---------- translation ----------
const MM = { zh: 'zh-CN' };
const mm = (c) => MM[c] || c;

/** MyMemory accepts at most 500 bytes per request, so split on sentence boundaries. */
export function chunkText(text, maxBytes = 450) {
  const parts = text.match(/[^.!?。！？\n]+[.!?。！？]*\s*/g) || [text];
  const out = []; let cur = '';
  const push = () => { if (cur.trim()) out.push(cur); cur = ''; };
  for (const p of parts) {
    if (Buffer.byteLength(cur + p) > maxBytes) push();
    if (Buffer.byteLength(p) > maxBytes) { // one very long sentence: hard split on characters
      for (const ch of p) { if (Buffer.byteLength(cur + ch) > maxBytes) push(); cur += ch; }
    } else cur += p;
  }
  push();
  return out;
}

async function libre(text, target, source) {
  const res = await http(`${config.libreUrl.replace(/\/$/, '')}/translate`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ q: text, source: source || 'auto', target, format: 'text', ...(config.libreKey ? { api_key: config.libreKey } : {}) }),
  });
  if (!res.ok) throw new FreeEngineError(`LibreTranslate error ${res.status}`, 502);
  const j = await res.json();
  return { translation: j.translatedText, source: source || j.detectedLanguage?.language };
}

// Expected script per target language: used to reject answers written in the wrong alphabet.
const SCRIPT_OF = { hi: /[\u0900-\u097F]/, mr: /[\u0900-\u097F]/, ne: /[\u0900-\u097F]/, th: /[\u0E00-\u0E7F]/, bn: /[\u0980-\u09FF]/, ta: /[\u0B80-\u0BFF]/,
  te: /[\u0C00-\u0C7F]/, gu: /[\u0A80-\u0AFF]/, kn: /[\u0C80-\u0CFF]/, ml: /[\u0D00-\u0D7F]/, he: /[\u0590-\u05FF]/, el: /[\u0370-\u03FF]/,
  ko: /[\uAC00-\uD7AF]/, ja: /[\u3040-\u30FF\u4E00-\u9FFF]/, zh: /[\u4E00-\u9FFF]/, ru: /[\u0400-\u04FF]/, uk: /[\u0400-\u04FF]/,
  ar: /[\u0600-\u06FF]/, fa: /[\u0600-\u06FF]/, ur: /[\u0600-\u06FF]/ };
const norm = (t) => String(t || '').toLowerCase().replace(/\s+/g, ' ').trim();
const clean = (t) => String(t || '').replace(/\s+/g, ' ').trim();

/**
 * MyMemory's headline answer can be a wrong crowd-sourced entry for a *different* sentence.
 * Prefer a candidate for exactly our sentence, written in the right script, with the best quality.
 */
export function pickBest(j, query, target) {
  const okScript = (t) => !SCRIPT_OF[target] || SCRIPT_OF[target].test(t);
  const cands = (j.matches || []).map((m) => ({ text: clean(m.translation), exact: norm(m.segment) === norm(query),
    q: Number(m.quality) || 0, match: Number(m.match) || 0 })).filter((c) => c.text && okScript(c.text));
  const rank = (a, b) => b.q - a.q || b.match - a.match;
  const exact = cands.filter((c) => c.exact).sort(rank)[0];
  if (exact) return exact.text;
  const head = clean(j.responseData?.translatedText);
  if (head && okScript(head) && Number(j.responseData?.match) >= 0.95) return head;
  const best = cands.sort(rank)[0];
  if (best) return best.text;
  return head && okScript(head) ? head : head;
}

async function myMemory(text, target, source) {
  const pieces = [];
  for (const q of chunkText(text)) {
    const url = new URL('https://api.mymemory.translated.net/get');
    url.searchParams.set('q', q);
    url.searchParams.set('langpair', `${source ? mm(source) : 'Autodetect'}|${mm(target)}`);
    if (config.myMemoryEmail) url.searchParams.set('de', config.myMemoryEmail);
    const res = await http(url);
    if (!res.ok) throw new FreeEngineError(`Free translation service error ${res.status}`, 502);
    const j = await res.json();
    if (String(j.responseStatus) === '429' || j.quotaFinished)
      throw new FreeEngineError('Free translation limit reached for today. Try again tomorrow, set MYMEMORY_EMAIL in .env for a higher limit, or switch to OpenAI in Settings.', 429);
    if (String(j.responseStatus) !== '200') throw new FreeEngineError(`Free translation failed: ${j.responseDetails || j.responseStatus}`, 502);
    pieces.push(pickBest(j, q, target));
  }
  return { translation: pieces.join(' ').replace(/\s+/g, ' ').trim(), source };
}

// Repeated phrases (travel phrases, replays, common sentences) cost no quota: small in-memory LRU cache.
const CACHE_MAX = 3000;
const cache = new Map();
export const clearTranslationCache = () => cache.clear();

export async function translate({ text, target, source }) {
  const src = source || detectLanguage(text) || undefined;
  if (src === target) return { source: src, translation: text, note: '' };
  const key = `${src || '?'}|${target}|${text}`;
  const hit = cache.get(key);
  if (hit) { cache.delete(key); cache.set(key, hit); return { ...hit }; }
  const r = config.libreUrl ? await libre(text, target, src) : await myMemory(text, target, src);
  const out = { source: r.source || src || 'en', translation: r.translation, note: '' };
  cache.set(key, out);
  if (cache.size > CACHE_MAX) cache.delete(cache.keys().next().value);
  return { ...out };
}

export async function translateBatch({ items, target }) {
  const out = [];
  for (const it of items) out.push((await translate({ text: it, target, source: 'en' })).translation);
  return out;
}

// ---------- OCR (Tesseract, runs on the server, free) ----------
const TESS = { en: 'eng', hi: 'hin', th: 'tha', ja: 'jpn', ko: 'kor', zh: 'chi_sim', es: 'spa', fr: 'fra', de: 'deu', it: 'ita', pt: 'por', ru: 'rus', ar: 'ara',
  bn: 'ben', ta: 'tam', te: 'tel', mr: 'mar', gu: 'guj', kn: 'kan', ml: 'mal', ur: 'urd', ne: 'nep', id: 'ind', ms: 'msa', vi: 'vie', tl: 'tgl', tr: 'tur',
  fa: 'fas', he: 'heb', nl: 'nld', pl: 'pol', sv: 'swe', el: 'ell', uk: 'ukr', cs: 'ces', ro: 'ron', sw: 'swa' };

let ocrImpl = async (buffer, langs) => {
  const { createWorker } = await import('tesseract.js');
  const worker = await createWorker(langs.join('+'));
  try { return (await worker.recognize(buffer)).data.text; } finally { await worker.terminate(); }
};
export const setOcr = (fn) => { ocrImpl = fn; };

export async function ocr({ buffer, hintLangs }) {
  const langs = [...new Set(hintLangs.map((c) => TESS[c]).filter(Boolean))].slice(0, 4);
  if (!langs.includes('eng')) langs.push('eng');
  try { return (await ocrImpl(buffer, langs)).replace(/[ \t]+\n/g, '\n').trim(); }
  catch (e) { throw new FreeEngineError(`Free text reading failed (${e.message}). The first use of a language downloads its data, so check the internet connection.`, 502); }
}
export { languageName };
