import { detectLanguage } from '../free.js';
/** Detector agent: which language is this text in? (offline, free). Returns a code or null. */
export const detector = {
  name: 'detector', title: 'Language Detector', job: 'Identifies the language of text',
  run: ({ text }) => detectLanguage(text),
};
