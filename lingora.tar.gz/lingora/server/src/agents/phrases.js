import { TRAVEL } from '../travel-data.js';
import { translator } from './translator.js';
/** Phrase agent: ready-made travel phrases per situation, translated on demand. */
export const phrases = {
  name: 'phrases', title: 'Travel Phrases', job: 'Provides ready-made travel phrases',
  scenarios: Object.keys(TRAVEL),
  run: ({ engine, scenario, lang }) => (lang === 'en' ? TRAVEL[scenario] : translator.batch({ engine, items: TRAVEL[scenario], target: lang })),
};
