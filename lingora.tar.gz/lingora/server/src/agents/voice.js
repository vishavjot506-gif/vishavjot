import * as ai from '../ai.js';
import { FreeEngineError } from '../free.js';
/** Voice agent: text -> spoken audio. Free engine uses the device's own voice (handled in the app). */
export const voice = {
  name: 'voice', title: 'Voice', job: 'Speaks translations aloud',
  run: ({ engine, ...a }) => {
    if (engine !== 'openai') throw new FreeEngineError('The free engine uses your device voice. Server voices need the OpenAI engine.');
    return ai.speak(a);
  },
};
