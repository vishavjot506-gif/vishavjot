import { listener } from './listener.js';
import { detector } from './detector.js';
import { translator } from './translator.js';
import { voice } from './voice.js';
import { vision } from './vision.js';
import { phrases } from './phrases.js';

export { listener, detector, translator, voice, vision, phrases };
export const AGENTS = [listener, detector, translator, voice, vision, phrases].map(({ name, title, job }) => ({ name, title, job }));

/**
 * Orchestrator for one spoken segment: Listener -> Detector -> Translator.
 * (OpenAI engine only; with the free engine, speech is recognised in the browser and the app calls Translator directly.)
 */
export async function speechToTranslation({ engine, audio, forced, hint, target, expectedSource, context, note }) {
  const heard = await listener.run({ engine, buffer: audio.buffer, filename: audio.originalname, mimetype: audio.mimetype, language: hint });
  if (heard.silent || !heard.text) return { silent: true };
  const source = forced ?? expectedSource ?? heard.language ?? detector.run({ text: heard.text }) ?? undefined;
  if (source && source === target) return { silent: false, original: heard.text, translated: heard.text, sourceLang: source, note: '' };
  const t = await translator.run({ engine, text: heard.text, target, source, context, note });
  return { silent: false, original: heard.text, translated: t.translation, sourceLang: source ?? t.source, note: t.note || '' };
}
