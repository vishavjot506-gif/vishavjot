import * as ai from '../ai.js';
import * as free from '../free.js';
import { detector } from './detector.js';
import { translator } from './translator.js';
/** Vision agent: photo -> extracted text -> translation. */
export const vision = {
  name: 'vision', title: 'Vision', job: 'Reads text in photos and translates it',
  async run({ engine, buffer, mimetype, target, hintLangs = [], ocrOnly = false }) {
    if (engine === 'openai') return ai.translateImage({ buffer, mimetype, target });
    const extracted = await free.ocr({ buffer, hintLangs });
    if (extracted.replace(/\s/g, '').length < 2) return { found: false, source: '', extracted: '', translation: '' };
    const source = detector.run({ text: extracted }) || hintLangs.find((l) => l !== target) || '';
    // ocrOnly: the browser translates (each user's own IP gets its own free-translation limit).
    if (ocrOnly) return { found: true, source, extracted, translation: '' };
    const t = await translator.run({ engine, text: extracted, target, source: source || undefined });
    return { found: true, source: t.source || source, extracted, translation: t.translation };
  },
};
