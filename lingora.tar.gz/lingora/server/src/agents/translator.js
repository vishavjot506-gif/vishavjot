import * as ai from '../ai.js';
import * as free from '../free.js';
/** Translator agent: text -> text in the target language. */
export const translator = {
  name: 'translator', title: 'Translator', job: 'Translates text into the target language',
  run: ({ engine, ...a }) => (engine === 'openai' ? ai.translate(a) : free.translate(a)),
  batch: ({ engine, ...a }) => (engine === 'openai' ? ai.translateBatch(a) : free.translateBatch(a)),
};
