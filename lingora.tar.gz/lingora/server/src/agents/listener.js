import * as ai from '../ai.js';
import { FreeEngineError } from '../free.js';
/** Listener agent: speech -> text. Free engine runs in the browser (Web Speech API); only OpenAI runs here. */
export const listener = {
  name: 'listener', title: 'Listener', job: 'Turns speech into text',
  run: ({ engine, ...args }) => {
    if (engine !== 'openai') throw new FreeEngineError('The free engine recognises speech in your browser (Chrome/Edge), not on the server. Use the web app, or switch to OpenAI in Settings.');
    return ai.transcribe(args);
  },
};
