// Minimal service worker: lets the browser treat Lingora as an installable app.
// It does not cache API calls (translations always need the network).
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
