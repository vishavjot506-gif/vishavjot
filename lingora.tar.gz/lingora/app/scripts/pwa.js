// Run after `expo export --platform web`: copies PWA files into dist/ and patches dist/index.html.
const fs = require('fs'); const path = require('path');
const dist = path.join(__dirname, '..', 'dist'); const src = path.join(__dirname, '..', 'pwa');
for (const f of fs.readdirSync(src)) fs.copyFileSync(path.join(src, f), path.join(dist, f));
const file = path.join(dist, 'index.html');
let html = fs.readFileSync(file, 'utf8');
const tags = `
    <link rel="manifest" href="/manifest.webmanifest" />
    <meta name="theme-color" content="#0A0F1F" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="apple-mobile-web-app-title" content="Lingora" />
    <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
    <link rel="icon" type="image/png" href="/icon-192.png" />`;
const sw = '<script src="/pwa-register.js" defer></script>';
if (!html.includes('rel="manifest"')) html = html.replace('</head>', `${tags}\n  </head>`);
if (!html.includes('pwa-register')) html = html.replace('</body>', `  ${sw}\n</body>`);
fs.writeFileSync(file, html);
console.log('PWA files added to dist/');
