import { Platform } from 'react-native';

// Android emulator reaches the host machine at 10.0.2.2. Set EXPO_PUBLIC_API_URL for devices/production.
const DEFAULT = Platform.OS === 'android' ? 'http://10.0.2.2:4000' : 'http://localhost:4000';
// Web: when the page is served by the Lingora server itself (hosting), use the same origin.
// During local development (`npm run web` on :8081) fall back to the API on :4000.
const webBase = () => {
  const { hostname, port, origin } = (globalThis as any).location;
  return (hostname === 'localhost' || hostname === '127.0.0.1') && port !== '4000' ? 'http://localhost:4000' : origin;
};
export const BASE = process.env.EXPO_PUBLIC_API_URL || (Platform.OS === 'web' ? webBase() : DEFAULT);

let token: string | null = null;
export const setToken = (t: string | null) => { token = t; };
let onUnauthorized: () => void = () => {};
export const setOnUnauthorized = (fn: () => void) => { onUnauthorized = fn; };

export class ApiError extends Error {
  constructor(message: string, public status: number, public code?: string) { super(message); }
}

async function raw(path: string, init: { method?: string; body?: any; form?: FormData } = {}) {
  const headers: Record<string, string> = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (init.body) headers['Content-Type'] = 'application/json';
  let res: Response;
  try {
    res = await fetch(BASE + path, { method: init.method || 'GET', headers, body: init.form ?? (init.body ? JSON.stringify(init.body) : undefined) });
  } catch {
    throw new ApiError(`Cannot reach the Lingora server at ${BASE}. Check your connection.`, 0);
  }
  if (!res.ok) {
    let msg = res.statusText; let code: string | undefined;
    try { const j = await res.json(); msg = j.error || msg; code = j.code; } catch {}
    if (res.status === 401 && token) onUnauthorized();
    throw new ApiError(msg, res.status, code);
  }
  return res;
}
const json = async (path: string, init?: Parameters<typeof raw>[1]) => {
  const res = await raw(path, init);
  return res.status === 204 ? null : res.json();
};

/** Append a file to FormData across web (Blob) and native ({uri,name,type}). */
export async function appendFile(form: FormData, field: string, f: { uri: string; name: string; type: string; blob?: Blob }) {
  if (f.blob) form.append(field, f.blob, f.name);
  else if (Platform.OS === 'web') form.append(field, await (await fetch(f.uri)).blob(), f.name);
  else form.append(field, { uri: f.uri, name: f.name, type: f.type } as any);
}

export const api = {
  register: (email: string, password: string, name: string) => json('/auth/register', { method: 'POST', body: { email, password, name } }),
  login: (email: string, password: string) => json('/auth/login', { method: 'POST', body: { email, password } }),
  me: () => json('/me'),
  updateMe: (patch: any) => json('/me', { method: 'PATCH', body: patch }),
  deleteMe: () => json('/me', { method: 'DELETE' }),
  languages: () => json('/languages'),
  engines: () => json('/engines'),
  translateText: (b: { text: string; target?: string; source?: string; note?: boolean }) => json('/translate/text', { method: 'POST', body: b }),
  translateSpeech: async (clip: any, fields: Record<string, string | undefined>) => {
    const form = new FormData();
    await appendFile(form, 'audio', clip);
    for (const [k, v] of Object.entries(fields)) if (v) form.append(k, v);
    return json('/speech/translate', { method: 'POST', form });
  },
  translateImage: async (file: any, target?: string, sourceLang?: string) => {
    const form = new FormData();
    await appendFile(form, 'image', file);
    if (target) form.append('target', target);
    if (sourceLang) form.append('sourceLang', sourceLang);
    return json('/vision/translate', { method: 'POST', form });
  },
  tts: async (text: string, voice?: string, speed?: number): Promise<ArrayBuffer> =>
    (await raw('/tts', { method: 'POST', body: { text, voice, speed } })).arrayBuffer(),
  travel: (scenario: string, lang: string) => json(`/travel/${scenario}?lang=${lang}`),
  // history
  createSession: (b: any) => json('/history/sessions', { method: 'POST', body: b }),
  addEntry: (id: number, b: any) => json(`/history/sessions/${id}/entries`, { method: 'POST', body: b }),
  sessions: () => json('/history/sessions'),
  session: (id: number) => json(`/history/sessions/${id}`),
  deleteSession: (id: number) => json(`/history/sessions/${id}`, { method: 'DELETE' }),
  clearHistory: () => json('/history', { method: 'DELETE' }),
  // phrases
  phrases: () => json('/phrases'),
  savePhrase: (b: any) => json('/phrases', { method: 'POST', body: b }),
  movePhrase: (id: number, folder: string) => json(`/phrases/${id}`, { method: 'PATCH', body: { folder } }),
  deletePhrase: (id: number) => json(`/phrases/${id}`, { method: 'DELETE' }),
};
