import React, { useState } from 'react';
import { ActivityIndicator, Pressable, SafeAreaView, ScrollView, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { AppProvider, useApp } from './app-context';
import { c } from './theme';
import AuthScreen from './screens/AuthScreen';
import OnboardingScreen from './screens/OnboardingScreen';
import ConversationScreen from './screens/ConversationScreen';
import LiveScreen from './screens/LiveScreen';
import TextScreen from './screens/TextScreen';
import CameraScreen from './screens/CameraScreen';
import TravelScreen from './screens/TravelScreen';
import HistoryScreen from './screens/HistoryScreen';
import PhrasesScreen from './screens/PhrasesScreen';
import SettingsScreen from './screens/SettingsScreen';

const TABS = [
  { key: 'conversation', label: 'Talk', icon: '💬', C: ConversationScreen },
  { key: 'live', label: 'Live', icon: '🎧', C: LiveScreen },
  { key: 'text', label: 'Text', icon: '✍️', C: TextScreen },
  { key: 'camera', label: 'Camera', icon: '📷', C: CameraScreen },
  { key: 'travel', label: 'Travel', icon: '✈️', C: TravelScreen },
  { key: 'phrases', label: 'Saved', icon: '⭐', C: PhrasesScreen },
  { key: 'history', label: 'History', icon: '🕘', C: HistoryScreen },
  { key: 'settings', label: 'Settings', icon: '⚙️', C: SettingsScreen },
] as const;

function Shell() {
  const { user, ready } = useApp();
  const [tab, setTab] = useState<(typeof TABS)[number]['key']>('conversation');
  if (!ready) return <View style={{ flex: 1, backgroundColor: c.bg, justifyContent: 'center' }}><ActivityIndicator color={c.primary} size="large" /></View>;
  if (!user) return <AuthScreen />;
  if (!user.onboarded) return <OnboardingScreen />;
  const Active = TABS.find((t) => t.key === tab)!.C;
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: c.bg }}>
      <View style={{ paddingHorizontal: 16, paddingTop: 10 }}>
        <Text style={{ color: c.text, fontWeight: '900', letterSpacing: 3, fontSize: 15 }}>LINGORA</Text>
      </View>
      <View style={{ flex: 1 }}><Active /></View>
      <View style={{ borderTopWidth: 1, borderColor: c.border, backgroundColor: c.surface }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1, justifyContent: 'space-around' }}>
          {TABS.map((t) => (
            <Pressable key={t.key} onPress={() => setTab(t.key)} accessibilityRole="tab" accessibilityLabel={t.label}
              style={{ paddingVertical: 8, paddingHorizontal: 12, alignItems: 'center', minWidth: 64 }}>
              <Text style={{ fontSize: 20 }}>{t.icon}</Text>
              <Text style={{ color: tab === t.key ? c.accent : c.muted, fontSize: 11, fontWeight: '700' }}>{t.label}</Text>
            </Pressable>))}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

export default function App() {
  return (<AppProvider><StatusBar style="light" /><Shell /></AppProvider>);
}
