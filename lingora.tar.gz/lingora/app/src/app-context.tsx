import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api, setOnUnauthorized, setToken } from './api';
import { storage } from './storage';
import { playMp3 } from './audio/player';
import * as Speech from 'expo-speech';
import { locale } from './bcp47';

export type Lang = { code: string; name: string; native: string };
export type User = {
  id: number; email: string; name: string; nativeLang: string; preferredLangs: string[]; defaultTarget: string;
  voice: string; voiceSpeed: number; historyEnabled: boolean; onboarded: boolean; engine: 'free' | 'openai';
};
type Ctx = {
  user: User | null; ready: boolean; languages: Lang[]; voices: string[]; scenarios: string[]; openaiAvailable: boolean; free: boolean;
  langName: (code?: string | null) => string;
  signIn: (token: string, user: User) => Promise<void>;
  signOut: () => Promise<void>;
  updateUser: (patch: Partial<User>) => Promise<void>;
  speak: (text: string, lang?: string) => Promise<void>;
};
const AppCtx = createContext<Ctx>(null as any);
export const useApp = () => useContext(AppCtx);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const [languages, setLanguages] = useState<Lang[]>([]);
  const [voices, setVoices] = useState<string[]>([]);
  const [scenarios, setScenarios] = useState<string[]>([]);
  const [openaiAvailable, setOpenaiAvailable] = useState(false);

  const signOut = useCallback(async () => { setToken(null); await storage.del('token'); setUser(null); }, []);
  useEffect(() => { setOnUnauthorized(() => { signOut(); }); }, [signOut]);

  useEffect(() => {
    (async () => {
      try {
        try { setOpenaiAvailable((await api.engines()).openaiAvailable); } catch {}
        const meta = await api.languages();
        setLanguages(meta.languages); setVoices(meta.voices); setScenarios(meta.scenarios);
        const t = await storage.get('token');
        if (t) { setToken(t); setUser((await api.me()).user); }
      } catch { /* offline or expired: fall through to sign-in */ }
      setReady(true);
    })();
  }, []);

  const signIn = useCallback(async (token: string, u: User) => {
    setToken(token); await storage.set('token', token); setUser(u);
    if (!languages.length) { const meta = await api.languages(); setLanguages(meta.languages); setVoices(meta.voices); setScenarios(meta.scenarios); }
  }, [languages.length]);

  const updateUser = useCallback(async (patch: Partial<User>) => { setUser((await api.updateMe(patch)).user); }, []);
  const langName = useCallback((code?: string | null) => (code ? languages.find((l) => l.code === code)?.name ?? code : '—'), [languages]);
  const speak = useCallback(async (text: string, lang?: string) => {
    if (!user) return;
    if (user.engine === 'openai') { await playMp3(await api.tts(text, user.voice, user.voiceSpeed)); return; }
    // Free engine: the device's own voice. Quality and available languages depend on the device.
    Speech.stop();
    Speech.speak(text, { language: locale(lang || user.nativeLang), rate: user.voiceSpeed });
  }, [user]);

  const free = user?.engine !== 'openai';
  const value = useMemo(() => ({ user, ready, languages, voices, scenarios, openaiAvailable, free, langName, signIn, signOut, updateUser, speak }),
    [user, ready, languages, voices, scenarios, openaiAvailable, free, langName, signIn, signOut, updateUser, speak]);
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}
