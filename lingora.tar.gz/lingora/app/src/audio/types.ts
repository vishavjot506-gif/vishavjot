export type Clip = { uri: string; name: string; type: string; blob?: Blob };
