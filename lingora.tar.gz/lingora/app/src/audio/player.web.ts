let el: HTMLAudioElement | null = null;
export function stopPlayback() { if (el) { el.pause(); el.src = ''; el = null; } }
export async function playMp3(buf: ArrayBuffer) {
  stopPlayback();
  const url = URL.createObjectURL(new Blob([buf], { type: 'audio/mpeg' }));
  el = new Audio(url);
  el.onended = () => URL.revokeObjectURL(url);
  await el.play();
}
