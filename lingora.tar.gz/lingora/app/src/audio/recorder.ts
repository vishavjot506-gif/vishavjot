import { AudioModule, RecordingPresets, requestRecordingPermissionsAsync, setAudioModeAsync } from 'expo-audio';
import type { Clip } from './types';

export async function ensureMic(): Promise<boolean> {
  const p = await requestRecordingPermissionsAsync();
  if (!p.granted) return false;
  await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
  return true;
}

const PRESET = { ...RecordingPresets.HIGH_QUALITY, sampleRate: 16000, numberOfChannels: 1, bitRate: 48000 };

/** Records one segment from start() to stop(). Create a new instance (or reuse) per segment. */
export class SegmentRecorder {
  private rec: any = null;
  async start() {
    await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
    this.rec = new (AudioModule as any).AudioRecorder(PRESET);
    await this.rec.prepareToRecordAsync();
    this.rec.record();
  }
  async stop(): Promise<Clip | null> {
    const rec = this.rec; this.rec = null;
    if (!rec) return null;
    try { await rec.stop(); } catch { return null; }
    const uri: string | null = rec.uri;
    try { rec.release?.(); } catch {}
    return uri ? { uri, name: 'speech.m4a', type: 'audio/m4a' } : null;
  }
  async cancel() { await this.stop(); }
}
