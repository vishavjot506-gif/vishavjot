import { locale } from '../bcp47';

const SR: any = typeof window !== 'undefined' ? (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition : null;
export const sttSupported = !!SR;
export type Recognizer = { start: () => void; stop: () => void };

/** Free browser speech recognition. In Chrome the audio is processed by Google's speech service. */
export function createRecognizer(o: {
  lang: string; continuous: boolean; onInterim?: (t: string) => void; onFinal: (t: string) => void;
  onError: (msg: string, fatal: boolean) => void; onEnd: () => void;
}): Recognizer {
  const r = new SR();
  r.lang = locale(o.lang); r.continuous = o.continuous; r.interimResults = true;
  r.onresult = (e: any) => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const res = e.results[i];
      if (res.isFinal) o.onFinal(String(res[0].transcript).trim()); else interim += res[0].transcript;
    }
    o.onInterim?.(interim);
  };
  r.onerror = (e: any) => {
    if (e.error === 'no-speech' || e.error === 'aborted') return;
    if (e.error === 'not-allowed' || e.error === 'service-not-allowed') o.onError('Microphone permission is blocked. Click the lock icon in the address bar and allow the microphone.', true);
    else if (e.error === 'network') o.onError('Free speech recognition needs an internet connection.', true);
    else if (e.error === 'language-not-supported') o.onError('Your browser cannot recognise this language. Try Chrome, or pick another language.', true);
    else o.onError(`Speech recognition error: ${e.error}`, false);
  };
  r.onend = o.onEnd;
  return { start: () => r.start(), stop: () => r.stop() };
}
