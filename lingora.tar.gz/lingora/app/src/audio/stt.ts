// Free speech recognition uses the browser's Web Speech API, which does not exist in the native apps.
export const sttSupported = false;
export type Recognizer = { start: () => void; stop: () => void };
export type RecognizerOptions = {
  lang: string; continuous: boolean; onInterim?: (t: string) => void; onFinal: (t: string) => void;
  onError: (msg: string, fatal: boolean) => void; onEnd: () => void;
};
export function createRecognizer(_o: RecognizerOptions): Recognizer { throw new Error('Speech recognition is not available in the phone app with the free engine.'); }
