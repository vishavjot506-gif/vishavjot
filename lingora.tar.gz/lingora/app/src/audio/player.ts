import { createAudioPlayer, setAudioModeAsync } from 'expo-audio';
import { File, Paths } from 'expo-file-system';

let current: ReturnType<typeof createAudioPlayer> | null = null;
export function stopPlayback() { try { current?.pause(); current?.remove(); } catch {} current = null; }

export async function playMp3(buf: ArrayBuffer) {
  stopPlayback();
  await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
  const file = new File(Paths.cache, `tts-${Date.now()}.mp3`);
  file.create({ overwrite: true });
  file.write(new Uint8Array(buf));
  const player = createAudioPlayer(file.uri);
  current = player;
  player.play();
}
