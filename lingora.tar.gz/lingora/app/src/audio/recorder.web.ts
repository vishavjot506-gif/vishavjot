import type { Clip } from './types';

let stream: MediaStream | null = null;
export async function ensureMic(): Promise<boolean> {
  try {
    if (!stream || !stream.active) stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    return true;
  } catch { return false; }
}

export class SegmentRecorder {
  private mr: MediaRecorder | null = null;
  private chunks: Blob[] = [];
  async start() {
    if (!(await ensureMic()) || !stream) throw new Error('Microphone unavailable');
    const mime = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'].find((m) => MediaRecorder.isTypeSupported(m));
    this.chunks = [];
    this.mr = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
    this.mr.ondataavailable = (e) => { if (e.data.size) this.chunks.push(e.data); };
    this.mr.start();
  }
  stop(): Promise<Clip | null> {
    const mr = this.mr; this.mr = null;
    if (!mr || mr.state === 'inactive') return Promise.resolve(null);
    return new Promise((resolve) => {
      mr.onstop = () => {
        const type = (mr.mimeType || 'audio/webm').split(';')[0];
        const blob = new Blob(this.chunks, { type });
        const ext = type.includes('mp4') ? 'm4a' : 'webm';
        resolve(blob.size > 800 ? { uri: URL.createObjectURL(blob), name: `speech.${ext}`, type, blob } : null);
      };
      mr.stop();
    });
  }
  async cancel() { await this.stop(); }
}
