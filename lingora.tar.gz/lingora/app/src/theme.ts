export const c = {
  bg: '#0A0F1F', surface: '#141B33', surface2: '#1C2547', border: '#2A3563',
  primary: '#6C7CFF', primaryDim: '#3B47A8', accent: '#2DD4BF', text: '#EEF1FF', muted: '#8E97BD',
  danger: '#FF6B7A', warn: '#FFC857', ok: '#3DDC97',
};
export const r = { sm: 10, md: 16, lg: 24 };
