// Free translation done in the user's own browser (MyMemory allows CORS), so every user gets their own
// rate limit instead of all sharing the hosting server's single IP.
import { api } from './api';
import { storage } from './storage';

const MM: Record<string, string> = { zh: 'zh-CN' };
const mm = (c: string) => MM[c] || c;

const SCRIPT_OF: Record<string, RegExp> = {
  hi: /[ऀ-ॿ]/, mr: /[ऀ-ॿ]/, ne: /[ऀ-ॿ]/, th: /[฀-๿]/, bn: /[ঀ-৿]/, ta: /[஀-௿]/,
  te: /[ఀ-౿]/, gu: /[઀-૿]/, kn: /[ಀ-೿]/, ml: /[ഀ-ൿ]/, he: /[֐-׿]/, el: /[Ͱ-Ͽ]/,
  ko: /[가-힯]/, ja: /[぀-ヿ一-鿿]/, zh: /[一-鿿]/, ru: /[Ѐ-ӿ]/, uk: /[Ѐ-ӿ]/,
  ar: /[؀-ۿ]/, fa: /[؀-ۿ]/, ur: /[؀-ۿ]/,
};
const norm = (t: string) => String(t || '').toLowerCase().replace(/\s+/g, ' ').trim();
const clean = (t: string) => String(t || '').replace(/\s+/g, ' ').trim();
const bytes = (t: string) => new TextEncoder().encode(t).length;

export class FreeTranslateError extends Error {}

/** MyMemory accepts at most 500 bytes per request. */
export function chunkText(text: string, max = 450): string[] {
  const parts = text.match(/[^.!?。！？\n]+[.!?。！？]*\s*/g) || [text];
  const out: string[] = []; let cur = '';
  const push = () => { if (cur.trim()) out.push(cur); cur = ''; };
  for (const p of parts) {
    if (bytes(cur + p) > max) push();
    if (bytes(p) > max) { for (const ch of p) { if (bytes(cur + ch) > max) push(); cur += ch; } } else cur += p;
  }
  push();
  return out;
}

/** MyMemory's headline answer can be a wrong crowd-sourced entry for a different sentence: prefer an exact-sentence, right-script candidate. */
export function pickBest(j: any, query: string, target: string): string {
  const ok = (t: string) => !SCRIPT_OF[target] || SCRIPT_OF[target].test(t);
  const cands = (j.matches || []).map((m: any) => ({ text: clean(m.translation), exact: norm(m.segment) === norm(query), q: Number(m.quality) || 0, match: Number(m.match) || 0 }))
    .filter((c: any) => c.text && ok(c.text));
  const rank = (a: any, b: any) => b.q - a.q || b.match - a.match;
  const exact = cands.filter((c: any) => c.exact).sort(rank)[0];
  if (exact) return exact.text;
  const head = clean(j.responseData?.translatedText);
  if (head && ok(head) && Number(j.responseData?.match) >= 0.95) return head;
  const best = cands.sort(rank)[0];
  return best ? best.text : head;
}

// Small cache (memory + device storage): repeated phrases cost no quota.
const mem = new Map<string, string>();
let loaded = false;
const KEY = 'ft-cache-v1';
async function load() {
  if (loaded) return; loaded = true;
  try { const raw = await storage.get(KEY); if (raw) for (const [k, v] of JSON.parse(raw)) mem.set(k, v); } catch {}
}
async function persist() {
  try { await storage.set(KEY, JSON.stringify([...mem.entries()].slice(-400))); } catch {}
}

async function one(q: string, source: string | undefined, target: string): Promise<string> {
  const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(q)}&langpair=${encodeURIComponent(`${source ? mm(source) : 'Autodetect'}|${mm(target)}`)}`;
  let res: Response;
  try { res = await fetch(url); } catch { throw new FreeTranslateError('Cannot reach the free translation service. Check your internet connection.'); }
  if (res.status === 429) throw new FreeTranslateError('The free translation service is busy or your free daily limit is used up. Try again later, or switch to OpenAI in Settings.');
  if (!res.ok) throw new FreeTranslateError(`Free translation service error (${res.status}).`);
  const j = await res.json();
  if (String(j.responseStatus) === '429' || j.quotaFinished) throw new FreeTranslateError('Your free daily translation limit is used up. It resets tomorrow, or switch to OpenAI in Settings.');
  if (String(j.responseStatus) !== '200') throw new FreeTranslateError(`Free translation failed: ${j.responseDetails || j.responseStatus}`);
  return pickBest(j, q, target);
}

export async function translateFree(b: { text: string; source?: string; target: string }) {
  await load();
  let source = b.source;
  if (!source) { try { source = (await api.detect(b.text)).source || undefined; } catch { /* fall back to MyMemory autodetect */ } }
  if (source && source === b.target) return { source, target: b.target, translation: b.text, note: '' };
  const key = `${source || '?'}|${b.target}|${b.text}`;
  const hit = mem.get(key);
  if (hit) return { source: source || 'en', target: b.target, translation: hit, note: '' };
  const pieces: string[] = [];
  for (const q of chunkText(b.text)) pieces.push(await one(q, source, b.target));
  const translation = pieces.join(' ').replace(/\s+/g, ' ').trim();
  mem.set(key, translation); persist();
  return { source: source || 'en', target: b.target, translation, note: '' };
}
