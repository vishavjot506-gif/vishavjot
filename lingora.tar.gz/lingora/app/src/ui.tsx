import React, { useState } from 'react';
import { ActivityIndicator, FlatList, Modal, Pressable, StyleSheet, Text, TextInput, View, ViewStyle, TextStyle } from 'react-native';
import { c, r } from './theme';
import { useApp } from './app-context';

export const Screen = ({ children, style }: { children: React.ReactNode; style?: ViewStyle }) => (
  <View style={[{ flex: 1, backgroundColor: c.bg, padding: 16 }, style]}>{children}</View>
);
export const H1 = ({ children }: { children: React.ReactNode }) => <Text style={{ color: c.text, fontSize: 26, fontWeight: '800', marginBottom: 4 }}>{children}</Text>;
export const Muted = ({ children, style }: { children: React.ReactNode; style?: TextStyle }) => <Text style={[{ color: c.muted, fontSize: 14 }, style]}>{children}</Text>;
export const Body = ({ children, style }: { children: React.ReactNode; style?: TextStyle }) => <Text style={[{ color: c.text, fontSize: 16 }, style]}>{children}</Text>;

export function Btn({ title, onPress, kind = 'primary', disabled, busy, style, small }: {
  title: string; onPress: () => void; kind?: 'primary' | 'ghost' | 'danger' | 'accent'; disabled?: boolean; busy?: boolean; style?: ViewStyle; small?: boolean;
}) {
  const bg = { primary: c.primary, accent: c.accent, ghost: 'transparent', danger: 'transparent' }[kind];
  const fg = kind === 'ghost' ? c.text : kind === 'danger' ? c.danger : kind === 'accent' ? '#04201C' : '#fff';
  const border = kind === 'ghost' ? c.border : kind === 'danger' ? c.danger : 'transparent';
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={title} onPress={onPress} disabled={disabled || busy}
      style={({ pressed }) => [{ backgroundColor: bg, borderColor: border, borderWidth: 1, borderRadius: r.md, paddingVertical: small ? 8 : 14, paddingHorizontal: small ? 12 : 18,
        alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.4 : pressed ? 0.8 : 1, flexDirection: 'row', gap: 8 }, style]}>
      {busy && <ActivityIndicator color={fg} />}
      <Text style={{ color: fg, fontWeight: '700', fontSize: small ? 14 : 16 }}>{title}</Text>
    </Pressable>
  );
}

export const Card = ({ children, style }: { children: React.ReactNode; style?: ViewStyle }) => (
  <View style={[{ backgroundColor: c.surface, borderRadius: r.md, padding: 14, borderWidth: 1, borderColor: c.border }, style]}>{children}</View>
);

export const Field = (p: React.ComponentProps<typeof TextInput>) => (
  <TextInput placeholderTextColor={c.muted} {...p}
    style={[{ backgroundColor: c.surface, color: c.text, borderRadius: r.md, borderWidth: 1, borderColor: c.border, padding: 14, fontSize: 16 }, p.style]} />
);

export const Chip = ({ label, onPress, active }: { label: string; onPress?: () => void; active?: boolean }) => (
  <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={label}
    style={{ backgroundColor: active ? c.primary : c.surface2, borderRadius: 999, paddingVertical: 7, paddingHorizontal: 14, borderWidth: 1, borderColor: active ? c.primary : c.border }}>
    <Text style={{ color: active ? '#fff' : c.text, fontWeight: '600' }}>{label}</Text>
  </Pressable>
);

export const ErrorText = ({ msg }: { msg?: string | null }) => (msg ? <Text style={{ color: c.danger, marginVertical: 6 }}>{msg}</Text> : null);

/** Tap to open a searchable language list. `allowAuto` adds an "Auto-detect" row (value ''). */
export function LangButton({ value, onChange, allowAuto, autoLabel = 'Auto-detect', prefix, include }: {
  value: string; onChange: (code: string) => void; allowAuto?: boolean; autoLabel?: string; prefix?: string; include?: string[];
}) {
  const { languages, langName } = useApp();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const list = languages.filter((l) => (!include || include.includes(l.code)) && (l.name + l.native).toLowerCase().includes(q.toLowerCase()));
  const data = allowAuto ? [{ code: '', name: autoLabel, native: '' }, ...list] : list;
  return (
    <>
      <Pressable onPress={() => setOpen(true)} accessibilityRole="button" accessibilityLabel={`${prefix ?? 'Language'}: ${value ? langName(value) : autoLabel}`}
        style={{ backgroundColor: c.surface2, borderRadius: r.sm, paddingVertical: 9, paddingHorizontal: 12, borderWidth: 1, borderColor: c.border, flexDirection: 'row', gap: 6 }}>
        {prefix ? <Text style={{ color: c.muted }}>{prefix}</Text> : null}
        <Text style={{ color: c.text, fontWeight: '700' }}>{value ? langName(value) : autoLabel} ▾</Text>
      </Pressable>
      <Modal visible={open} animationType="slide" onRequestClose={() => setOpen(false)}>
        <View style={{ flex: 1, backgroundColor: c.bg, padding: 16, paddingTop: 48 }}>
          <Field placeholder="Search language" value={q} onChangeText={setQ} autoFocus />
          <FlatList style={{ marginTop: 12 }} data={data} keyExtractor={(l) => l.code || 'auto'}
            renderItem={({ item }) => (
              <Pressable onPress={() => { onChange(item.code); setOpen(false); setQ(''); }}
                style={{ paddingVertical: 14, borderBottomWidth: 1, borderColor: c.border, flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={{ color: item.code === value ? c.accent : c.text, fontSize: 17, fontWeight: item.code === value ? '800' : '500' }}>{item.name}</Text>
                <Text style={{ color: c.muted }}>{item.native}</Text>
              </Pressable>)} />
          <Btn title="Close" kind="ghost" onPress={() => { setOpen(false); setQ(''); }} style={{ marginTop: 8 }} />
        </View>
      </Modal>
    </>
  );
}

export const s = StyleSheet.create({ row: { flexDirection: 'row', alignItems: 'center', gap: 10 } });
