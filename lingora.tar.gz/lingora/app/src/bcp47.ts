// Locale tags for the browser's speech recognition and device voices.
const LOCALE: Record<string, string> = {
  en: 'en-US', hi: 'hi-IN', th: 'th-TH', ja: 'ja-JP', ko: 'ko-KR', zh: 'zh-CN', es: 'es-ES', fr: 'fr-FR', de: 'de-DE', it: 'it-IT', pt: 'pt-BR',
  ru: 'ru-RU', ar: 'ar-SA', bn: 'bn-IN', ta: 'ta-IN', te: 'te-IN', mr: 'mr-IN', gu: 'gu-IN', kn: 'kn-IN', ml: 'ml-IN', ur: 'ur-PK', ne: 'ne-NP',
  id: 'id-ID', ms: 'ms-MY', vi: 'vi-VN', tl: 'fil-PH', tr: 'tr-TR', fa: 'fa-IR', he: 'he-IL', nl: 'nl-NL', pl: 'pl-PL', sv: 'sv-SE', el: 'el-GR',
  uk: 'uk-UA', cs: 'cs-CZ', ro: 'ro-RO', sw: 'sw-KE',
};
export const locale = (code: string) => LOCALE[code] || code;
