import { useCallback, useRef } from 'react';
import { api } from './api';
import { useApp } from './app-context';

/** Saves entries to history only when the user has enabled it. Failures never interrupt translation. */
export function useHistory(mode: 'conversation' | 'live' | 'text' | 'camera') {
  const { user } = useApp();
  const sid = useRef<number | null>(null);
  const record = useCallback(async (e: { speaker?: 'me' | 'other'; original: string; translated: string; sourceLang?: string; targetLang?: string }) => {
    if (!user?.historyEnabled) return;
    try {
      if (sid.current == null) sid.current = (await api.createSession({ mode, sourceLang: e.sourceLang, targetLang: e.targetLang })).id;
      await api.addEntry(sid.current!, e);
    } catch { /* history is best-effort */ }
  }, [user?.historyEnabled, mode]);
  const reset = useCallback(() => { sid.current = null; }, []);
  return { record, reset };
}
