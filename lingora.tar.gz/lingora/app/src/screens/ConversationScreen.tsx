import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FlatList, Pressable, Text, View } from 'react-native';
import { api } from '../api';
import { useApp } from '../app-context';
import { SegmentRecorder, ensureMic } from '../audio/recorder';
import { stopPlayback } from '../audio/player';
import type { Clip } from '../audio/types';
import { createRecognizer, sttSupported, type Recognizer } from '../audio/stt';
import { useHistory } from '../hooks';
import { Btn, Card, ErrorText, LangButton, Muted, Screen } from '../ui';
import { c, r } from '../theme';

type Turn = { id: number; speaker: 'me' | 'other'; original: string; translated: string; sourceLang?: string; targetLang?: string; clip?: Clip };

export default function ConversationScreen() {
  const { user, langName, speak, free } = useApp();
  const { record, reset } = useHistory('conversation');
  const [active, setActive] = useState(false);
  const [partner, setPartner] = useState('');           // '' = not known yet (auto-detected on their first turn)
  const [turns, setTurns] = useState<Turn[]>([]);
  const [recording, setRecording] = useState<'me' | 'other' | null>(null);
  const [busy, setBusy] = useState(false);
  const [paused, setPaused] = useState(false);
  const [muted, setMuted] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const rec = useRef(new SegmentRecorder());
  const pausedRef = useRef(false); pausedRef.current = paused;
  const nextId = useRef(1);
  const recog = useRef<Recognizer | null>(null);

  const say = useCallback((t: string, lang?: string) => { if (voiceOn && !pausedRef.current) speak(t, lang).catch(() => {}); }, [voiceOn, speak]);

  const begin = async () => {
    setErr(null);
    if (free) {
      if (!sttSupported) { setErr('Free speech recognition works in the web app on Chrome or Edge (also Chrome on Android). In the phone app, turn on OpenAI in Settings.'); return; }
    } else if (!(await ensureMic())) { setErr('Microphone permission is needed to translate speech. Enable it in your device or browser settings.'); return; }
    setActive(true);
  };
  const end = async () => {
    await rec.current.cancel(); recog.current?.stop(); recog.current = null; stopPlayback();
    setActive(false); setTurns([]); setRecording(null); setPaused(false); setMuted(false); setPartner(''); reset();
  };
  useEffect(() => () => { rec.current.cancel(); stopPlayback(); }, []);

  // Free engine: browser speech recognition (needs the language up front; it cannot auto-detect).
  const toggleFree = (who: 'me' | 'other') => {
    if (recording === who) { recog.current?.stop(); return; }
    if (recording || busy) return;
    const lang = who === 'me' ? user!.nativeLang : partner;
    if (!lang) { setErr('Free mode cannot auto-detect speech. Pick the other person\'s language (top right) first.'); return; }
    const parts: string[] = [];
    stopPlayback();
    try {
      const r = createRecognizer({
        lang, continuous: true,
        onFinal: (t) => { if (t) parts.push(t); },
        onError: (m) => setErr(m),
        onEnd: async () => {
          recog.current = null; setRecording(null);
          const text = parts.join(' ').trim();
          if (!text) { setErr('No speech detected. Try again a little louder.'); return; }
          setBusy(true);
          try {
            const target = who === 'me' ? partner : user!.nativeLang;
            const res = await api.translateText({ text, source: lang, target });
            setTurns((t) => [...t, { id: nextId.current++, speaker: who, original: text, translated: res.translation, sourceLang: lang, targetLang: target }]);
            say(res.translation, target);
            record({ speaker: who, original: text, translated: res.translation, sourceLang: lang, targetLang: target });
          } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
        },
      });
      recog.current = r; r.start(); setRecording(who);
    } catch (e: any) { setErr(e.message); }
  };

  const toggle = async (who: 'me' | 'other') => {
    setErr(null);
    if (free) return toggleFree(who);
    if (recording === who) {
      setRecording(null); setBusy(true);
      try {
        const clip = await rec.current.stop();
        if (!clip) { setErr('Nothing was recorded. Hold the phone closer and try again.'); return; }
        await process(clip, who);
      } catch (e: any) {
        if (e.code === 'partner_language_unknown') setErr('Pick the other person\'s language (top right), then speak again.');
        else setErr(e.message);
      } finally { setBusy(false); }
      return;
    }
    if (recording || busy) return;
    if (who === 'me' && !partner) { setErr('Pick the other person\'s language first, or let them speak first so Lingora can detect it.'); return; }
    try { stopPlayback(); await rec.current.start(); setRecording(who); } catch (e: any) { setErr(e.message || 'Could not start the microphone'); }
  };

  const process = async (clip: Clip, who: 'me' | 'other', sourceLang?: string, replaceId?: number) => {
    const last = turns[turns.length - 1];
    const res = await api.translateSpeech(clip, { mode: 'turn', speaker: who, partnerLang: partner || undefined, sourceLang, context: last?.original });
    if (res.silent) { setErr('No speech detected. Try again a little louder.'); return; }
    if (who === 'other' && !partner && res.sourceLang && res.sourceLang !== user!.nativeLang) setPartner(res.sourceLang);
    const turn: Turn = { id: replaceId ?? nextId.current++, speaker: who, original: res.original, translated: res.translated, sourceLang: res.sourceLang, targetLang: res.targetLang, clip };
    setTurns((t) => (replaceId ? t.map((x) => (x.id === replaceId ? turn : x)) : [...t, turn]));
    say(res.translated, res.targetLang);
    if (!replaceId) record({ speaker: who, original: res.original, translated: res.translated, sourceLang: res.sourceLang, targetLang: res.targetLang });
  };

  const correct = async (t: Turn, code: string) => {
    if (!t.clip) return;
    setBusy(true); setErr(null);
    try { await process(t.clip, t.speaker, code, t.id); if (t.speaker === 'other' && code !== user!.nativeLang) setPartner(code); }
    catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  if (!active) return (
    <Screen style={{ justifyContent: 'center', gap: 14 }}>
      <Text style={{ color: c.text, fontSize: 28, fontWeight: '800' }}>Two-way conversation</Text>
      <Muted>Pass the phone back and forth. You speak {langName(user!.nativeLang)}; the other person can speak any language and Lingora detects it.</Muted>
      <ErrorText msg={err} />
      <Btn title="Start conversation" onPress={begin} />
      <Muted>Shared-device turn-taking: tap a button, speak, tap again. Lingora does not identify speakers by voice.</Muted>
      {free && <Muted>Free mode: pick the other person's language yourself (speech cannot be auto-detected). Works in Chrome or Edge.</Muted>}
    </Screen>);

  return (
    <Screen>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, flexWrap: 'wrap', gap: 8 }}>
        <Muted>You: {langName(user!.nativeLang)}</Muted>
        <LangButton value={partner} onChange={setPartner} allowAuto autoLabel="Auto-detect" prefix="Other:" include={undefined} />
      </View>
      <FlatList data={turns} keyExtractor={(t) => String(t.id)} style={{ flex: 1 }} contentContainerStyle={{ gap: 10, paddingBottom: 10 }}
        ListEmptyComponent={<Muted style={{ textAlign: 'center', marginTop: 40 }}>Tap a microphone below to begin.</Muted>}
        renderItem={({ item: t }) => (
          <View style={{ alignSelf: t.speaker === 'me' ? 'flex-end' : 'flex-start', maxWidth: '88%' }}>
            <Card style={{ backgroundColor: t.speaker === 'me' ? c.primaryDim : c.surface, gap: 4 }}>
              <Text style={{ color: c.accent, fontSize: 12, fontWeight: '800' }}>{t.speaker === 'me' ? 'YOU' : 'OTHER PERSON'} · {langName(t.sourceLang)}</Text>
              <Text style={{ color: c.muted, fontSize: 14 }}>{t.original}</Text>
              <Text style={{ color: c.text, fontSize: 22, fontWeight: '700' }}>{t.translated}</Text>
              <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center', marginTop: 4 }}>
                <Btn small kind="ghost" title="🔊 Replay" onPress={() => speak(t.translated, t.targetLang).catch((e) => setErr(e.message))} />
                {!!t.clip && <LangButton value={t.sourceLang || ''} onChange={(code) => code && correct(t, code)} prefix="Wrong language?" />}
              </View>
            </Card>
          </View>)} />
      <ErrorText msg={err} />
      {paused && <Muted style={{ textAlign: 'center', color: c.warn }}>Paused</Muted>}
      <View style={{ flexDirection: 'row', gap: 10, marginVertical: 8 }}>
        {(['other', 'me'] as const).map((who) => {
          const on = recording === who;
          const disabled = paused || muted || busy || (!!recording && !on);
          return (
            <Pressable key={who} onPress={() => toggle(who)} disabled={disabled} accessibilityRole="button"
              accessibilityLabel={`${on ? 'Stop' : 'Start'} recording ${who === 'me' ? 'yourself' : 'other person'}`}
              style={{ flex: 1, height: 96, borderRadius: r.lg, alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.35 : 1,
                backgroundColor: on ? c.danger : who === 'me' ? c.primary : c.surface2, borderWidth: 1, borderColor: c.border }}>
              <Text style={{ fontSize: 28 }}>{on ? '⏹' : '🎙️'}</Text>
              <Text style={{ color: '#fff', fontWeight: '800' }}>{on ? 'Tap to finish' : who === 'me' ? `You (${langName(user!.nativeLang)})` : `Other (${partner ? langName(partner) : 'auto'})`}</Text>
            </Pressable>);
        })}
      </View>
      {busy && <Muted style={{ textAlign: 'center' }}>Translating…</Muted>}
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
        <Btn small kind="ghost" title={paused ? '▶ Resume' : '⏸ Pause'} onPress={async () => { if (!paused) { await rec.current.cancel(); recog.current?.stop(); setRecording(null); stopPlayback(); } setPaused(!paused); }} />
        <Btn small kind="ghost" title={muted ? '🔇 Mic muted' : '🎤 Mute mic'} onPress={async () => { if (!muted) { await rec.current.cancel(); recog.current?.stop(); setRecording(null); } setMuted(!muted); }} />
        <Btn small kind="ghost" title={voiceOn ? '🔊 Voice on' : '🔈 Voice off'} onPress={() => { stopPlayback(); setVoiceOn(!voiceOn); }} />
        <Btn small kind="danger" title="End" onPress={end} />
      </View>
    </Screen>
  );
}
