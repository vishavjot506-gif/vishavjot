import React, { useEffect, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { api } from '../api';
import { useApp } from '../app-context';
import { Btn, Card, Chip, ErrorText, H1, LangButton, Muted, Body } from '../ui';
import { c } from '../theme';

const LABEL: Record<string, string> = { airport: '🛫 Airport', hotel: '🏨 Hotel', restaurant: '🍜 Restaurant', shopping: '🛍 Shopping', taxi: '🚕 Taxi', directions: '🧭 Directions', emergency: '🚨 Emergency' };

export default function TravelScreen() {
  const { user, scenarios, speak } = useApp();
  const [scenario, setScenario] = useState('airport');
  const [dest, setDest] = useState(user!.preferredLangs[0] || user!.defaultTarget);
  const [mine, setMine] = useState<string[]>([]); const [theirs, setTheirs] = useState<string[]>([]);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null);
  const [saved, setSaved] = useState<Set<number>>(new Set());

  useEffect(() => {
    let live = true; setBusy(true); setErr(null); setSaved(new Set());
    Promise.all([api.travel(scenario, user!.nativeLang), api.travel(scenario, dest)])
      .then(([a, b]) => { if (live) { setMine(a.phrases); setTheirs(b.phrases); } })
      .catch((e) => live && setErr(e.message)).finally(() => live && setBusy(false));
    return () => { live = false; };
  }, [scenario, dest, user!.nativeLang]);

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, gap: 12 }}>
      <H1>Travel assistant</H1>
      <View style={{ flexDirection: 'row' }}><LangButton value={dest} onChange={setDest} prefix="I'm speaking to:" /></View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        {scenarios.map((s) => <Chip key={s} label={LABEL[s] || s} active={s === scenario} onPress={() => setScenario(s)} />)}
      </ScrollView>
      <ErrorText msg={err} />
      {busy && <Muted>Loading phrases…</Muted>}
      {!busy && theirs.map((t, i) => (
        <Card key={i} style={{ gap: 4, borderColor: scenario === 'emergency' ? c.danger : c.border }}>
          <Muted>{mine[i]}</Muted>
          <Body style={{ fontSize: 22, fontWeight: '700' }}>{t}</Body>
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
            <Btn small kind="ghost" title="🔊 Play" onPress={() => speak(t, dest).catch((e) => setErr(e.message))} />
            <Btn small kind="ghost" title={saved.has(i) ? '★ Saved' : '☆ Save'} disabled={saved.has(i)}
              onPress={async () => { try { await api.savePhrase({ folder: LABEL[scenario]?.slice(3) || 'Travel', original: mine[i], translated: t, sourceLang: user!.nativeLang, targetLang: dest }); setSaved(new Set(saved).add(i)); } catch (e: any) { setErr(e.message); } }} />
          </View>
        </Card>))}
      <Muted>Phrases are AI-translated and cached. For emergencies, also show the screen to a local person.</Muted>
    </ScrollView>
  );
}
