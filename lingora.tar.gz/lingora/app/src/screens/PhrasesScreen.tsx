import React, { useCallback, useEffect, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { api } from '../api';
import { useApp } from '../app-context';
import { Btn, Card, Chip, ErrorText, Field, H1, Muted, Body } from '../ui';
import { c } from '../theme';

export default function PhrasesScreen() {
  const { speak, langName } = useApp();
  const [items, setItems] = useState<any[]>([]);
  const [folder, setFolder] = useState<string>('All');
  const [moving, setMoving] = useState<number | null>(null);
  const [name, setName] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const load = useCallback(() => api.phrases().then((r: any) => setItems(r.phrases)).catch((e: any) => setErr(e.message)), []);
  useEffect(() => { load(); }, [load]);
  const folders = ['All', ...Array.from(new Set(items.map((i) => i.folder)))];
  const shown = items.filter((i) => folder === 'All' || i.folder === folder);
  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, gap: 12 }} keyboardShouldPersistTaps="handled">
      <H1>Saved phrases</H1>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        {folders.map((f) => <Chip key={f} label={f} active={f === folder} onPress={() => setFolder(f)} />)}
      </ScrollView>
      <ErrorText msg={err} />
      {!shown.length && <Muted>Nothing saved yet. Save sentences from Text, Live Listening or Travel.</Muted>}
      {shown.map((p) => (
        <Card key={p.id} style={{ gap: 4 }}>
          <Muted>{p.original}{p.source_lang ? ` (${langName(p.source_lang)})` : ''}</Muted>
          <Body style={{ fontSize: 20, fontWeight: '700' }}>{p.translated}</Body>
          <Muted style={{ fontSize: 12 }}>{p.folder}{p.target_lang ? ` · ${langName(p.target_lang)}` : ''}</Muted>
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 4, flexWrap: 'wrap' }}>
            <Btn small kind="ghost" title="🔊 Play" onPress={() => speak(p.translated, p.target_lang || undefined).catch((e) => setErr(e.message))} />
            <Btn small kind="ghost" title="Move" onPress={() => { setMoving(moving === p.id ? null : p.id); setName(''); }} />
            <Btn small kind="danger" title="Delete" onPress={async () => { await api.deletePhrase(p.id); load(); }} />
          </View>
          {moving === p.id && (
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 6 }}>
              <Field style={{ flex: 1, padding: 8 }} placeholder="Folder name" value={name} onChangeText={setName} />
              <Btn small title="Save" disabled={!name.trim()} onPress={async () => { await api.movePhrase(p.id, name.trim()); setMoving(null); load(); }} />
            </View>)}
        </Card>))}
    </ScrollView>
  );
}
