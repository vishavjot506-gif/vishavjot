import React, { useCallback, useEffect, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { api } from '../api';
import { useApp } from '../app-context';
import { Btn, Card, ErrorText, H1, Muted, Body } from '../ui';
import { c } from '../theme';

const when = (s: string) => new Date(s.replace(' ', 'T') + 'Z').toLocaleString();
const MODE: Record<string, string> = { conversation: 'Conversation', live: 'Live Listening', text: 'Text', camera: 'Camera' };

export default function HistoryScreen() {
  const { user, langName, updateUser } = useApp();
  const [sessions, setSessions] = useState<any[]>([]);
  const [open, setOpen] = useState<{ id: number; entries: any[] } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const load = useCallback(() => api.sessions().then((r: any) => setSessions(r.sessions)).catch((e: any) => setErr(e.message)), []);
  useEffect(() => { load(); }, [load]);

  if (!user!.historyEnabled) return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
      <H1>History is off</H1>
      <Muted>Lingora only keeps transcripts and translations when you turn history on. Raw audio is never saved either way.</Muted>
      <Btn title="Turn on history" onPress={() => updateUser({ historyEnabled: true })} />
      {sessions.length > 0 && <Muted>You still have {sessions.length} older session(s) saved.</Muted>}
    </ScrollView>);

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, gap: 12 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <H1>History</H1>
        {sessions.length > 0 && <Btn small kind="danger" title="Clear all" onPress={async () => { await api.clearHistory(); setOpen(null); load(); }} />}
      </View>
      <ErrorText msg={err} />
      {!sessions.length && <Muted>No saved sessions yet.</Muted>}
      {sessions.map((s) => (
        <Card key={s.id} style={{ gap: 4 }}>
          <Body style={{ fontWeight: '700' }}>{MODE[s.mode] || s.mode}</Body>
          <Muted>{when(s.created_at)} · {langName(s.source_lang)} → {langName(s.target_lang)} · {s.entry_count} item(s)</Muted>
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
            <Btn small kind="ghost" title={open?.id === s.id ? 'Hide' : 'View'} onPress={async () => setOpen(open?.id === s.id ? null : { id: s.id, entries: (await api.session(s.id)).entries })} />
            <Btn small kind="danger" title="Delete" onPress={async () => { await api.deleteSession(s.id); if (open?.id === s.id) setOpen(null); load(); }} />
          </View>
          {open && open.id === s.id && open.entries.map((e) => (
            <View key={e.id} style={{ borderTopWidth: 1, borderColor: c.border, paddingTop: 8, marginTop: 8 }}>
              <Muted>{when(e.created_at)} · {e.speaker === 'me' ? 'You' : 'Other'} · {langName(e.source_lang)} → {langName(e.target_lang)}</Muted>
              <Muted>{e.original}</Muted><Body style={{ fontWeight: '700' }}>{e.translated}</Body>
            </View>))}
        </Card>))}
    </ScrollView>
  );
}
