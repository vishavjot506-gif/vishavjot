import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, Text, View } from 'react-native';
import { api } from '../api';
import { useApp } from '../app-context';
import { Btn, ErrorText, Field, Muted } from '../ui';
import { c } from '../theme';

export default function AuthScreen() {
  const { signIn } = useApp();
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null);
  const submit = async () => {
    setBusy(true); setErr(null);
    try {
      const res = mode === 'register' ? await api.register(email.trim(), password, name.trim()) : await api.login(email.trim(), password);
      await signIn(res.token, res.user);
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };
  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: c.bg }}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24, gap: 12, maxWidth: 480, width: '100%', alignSelf: 'center' }}>
        <Text style={{ color: c.text, fontSize: 40, fontWeight: '900', letterSpacing: 6 }}>LINGORA</Text>
        <Text style={{ color: c.accent, fontSize: 17, fontWeight: '600', marginBottom: 24 }}>Every Language. One Conversation.</Text>
        {mode === 'register' && <Field placeholder="Your name" value={name} onChangeText={setName} />}
        <Field placeholder="Email" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
        <Field placeholder="Password (min 8 characters)" secureTextEntry value={password} onChangeText={setPassword} onSubmitEditing={submit} />
        <ErrorText msg={err} />
        <Btn title={mode === 'register' ? 'Create account' : 'Sign in'} onPress={submit} busy={busy} />
        <Btn kind="ghost" title={mode === 'register' ? 'I already have an account' : 'Create a new account'} onPress={() => setMode(mode === 'register' ? 'login' : 'register')} />
        <View><Muted>One account works on web, Android and iOS.</Muted></View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
