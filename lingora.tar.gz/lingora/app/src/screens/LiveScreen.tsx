import React, { useEffect, useRef, useState } from 'react';
import { FlatList, Modal, Pressable, Text, View } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { api } from '../api';
import { useApp } from '../app-context';
import { SegmentRecorder, ensureMic } from '../audio/recorder';
import { createRecognizer, sttSupported } from '../audio/stt';
import { useHistory } from '../hooks';
import { Btn, ErrorText, LangButton, Muted, Screen } from '../ui';
import { c } from '../theme';

type Line = { id: number; original: string; translated: string; sourceLang?: string; saved?: boolean };
const SEGMENT_MS = 4500;

export default function LiveScreen() {
  const { user, langName, free } = useApp();
  const { record, reset } = useHistory('live');
  const [state, setState] = useState<'idle' | 'listening' | 'paused'>('idle');
  const [lines, setLines] = useState<Line[]>([]);
  const [lang, setLang] = useState('');           // '' = auto-detect, otherwise manual lock
  const [detected, setDetected] = useState('');
  const [font, setFont] = useState(24);
  const [full, setFull] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [pending, setPending] = useState(0);
  const [interim, setInterim] = useState('');
  const loop = useRef({ running: false, rec: new SegmentRecorder(), timer: null as any, seq: 0, shown: 0, ready: new Map<number, Line | null>(), fr: null as any });
  const langRef = useRef(lang); langRef.current = lang;
  const linesRef = useRef<Line[]>([]); linesRef.current = lines;
  const list = useRef<FlatList<Line>>(null);

  // Results can come back out of order; reveal them strictly in capture order.
  const flush = () => {
    const L = loop.current;
    while (L.ready.has(L.shown)) {
      const l = L.ready.get(L.shown); L.ready.delete(L.shown); L.shown++;
      if (l) setLines((x) => [...x, l]);
    }
  };

  const cut = async () => {
    const L = loop.current;
    if (!L.running) return;
    const clip = await L.rec.stop();
    try { await L.rec.start(); } catch (e: any) { setErr(e.message); stop(); return; }   // keep capturing while the last segment uploads
    L.timer = setTimeout(cut, SEGMENT_MS);
    if (!clip) return;
    const n = L.seq++; setPending((p) => p + 1);
    const ctx = linesRef.current[linesRef.current.length - 1]?.original;
    api.translateSpeech(clip, { mode: 'live', sourceLang: langRef.current || undefined, context: ctx })
      .then((res) => {
        if (res.silent) { L.ready.set(n, null); return; }
        if (res.sourceLang) setDetected(res.sourceLang);
        const line = { id: n, original: res.original, translated: res.translated, sourceLang: res.sourceLang };
        L.ready.set(n, line);
        record({ original: res.original, translated: res.translated, sourceLang: res.sourceLang, targetLang: res.targetLang });
      })
      .catch((e) => { L.ready.set(n, null); setErr(e.message); })
      .finally(() => { setPending((p) => p - 1); flush(); });
  };

  // Free engine: continuous browser recognition; every finished phrase is translated as it arrives.
  const startFree = () => {
    if (!sttSupported) { setErr('Free speech recognition works in the web app on Chrome or Edge (also Chrome on Android). In the phone app, turn on OpenAI in Settings.'); return; }
    if (!langRef.current) { setErr('Free mode cannot auto-detect speech. Choose the speaker\'s language (top right) first.'); return; }
    const L = loop.current; L.running = true;
    const boot = () => {
      const src = langRef.current;
      const r = createRecognizer({
        lang: src, continuous: true, onInterim: setInterim,
        onFinal: (t) => {
          setInterim(''); if (!t) return;
          const n = L.seq++; setPending((p) => p + 1);
          api.translateText({ text: t, source: src, target: user!.nativeLang })
            .then((res) => { L.ready.set(n, { id: n, original: t, translated: res.translation, sourceLang: src }); record({ original: t, translated: res.translation, sourceLang: src, targetLang: user!.nativeLang }); })
            .catch((e) => { L.ready.set(n, null); setErr(e.message); })
            .finally(() => { setPending((p) => p - 1); flush(); });
        },
        onError: (m, fatal) => { setErr(m); if (fatal) { L.running = false; setState('idle'); } },
        onEnd: () => { L.fr = null; if (L.running) setTimeout(() => L.running && boot(), 250); },   // browsers end sessions after pauses
      });
      L.fr = r; try { r.start(); } catch { /* already started */ }
    };
    boot(); setState('listening');
  };

  const start = async () => {
    setErr(null);
    if (free) { startFree(); return; }
    if (!(await ensureMic())) { setErr('Microphone permission is needed. Enable it in your device or browser settings.'); return; }
    const L = loop.current;
    try { await L.rec.start(); } catch (e: any) { setErr(e.message); return; }
    L.running = true; L.timer = setTimeout(cut, SEGMENT_MS); setState('listening');
  };
  const halt = async (discard = true) => {
    const L = loop.current; L.running = false; clearTimeout(L.timer); L.fr?.stop(); L.fr = null; setInterim('');
    const clip = await L.rec.stop();
    if (!discard && clip) { /* final partial segment is dropped on pause/stop to keep latency simple */ }
  };
  const pause = async () => { await halt(); setState('paused'); };
  const stop = async () => { await halt(); setState('idle'); };
  const newSession = () => { setLines([]); loop.current.seq = 0; loop.current.shown = 0; loop.current.ready.clear(); setDetected(''); reset(); };
  useEffect(() => () => { halt(); }, []);
  useEffect(() => { list.current?.scrollToEnd({ animated: true }); }, [lines.length]);

  const save = async (l: Line) => {
    try { await api.savePhrase({ folder: 'Bookmarks', original: l.original, translated: l.translated, sourceLang: l.sourceLang, targetLang: user!.nativeLang }); setLines((x) => x.map((y) => (y.id === l.id ? { ...y, saved: true } : y))); }
    catch (e: any) { setErr(e.message); }
  };
  const copy = () => Clipboard.setStringAsync(lines.map((l) => `${l.original}\n${l.translated}`).join('\n\n'));

  const subtitles = (big: boolean) => (
    <FlatList ref={big ? undefined : list} data={big ? lines.slice(-4) : lines} keyExtractor={(l) => String(l.id)} style={{ flex: 1 }} contentContainerStyle={{ gap: 14, paddingVertical: 8, justifyContent: big ? 'flex-end' : undefined, flexGrow: 1 }}
      ListEmptyComponent={<Muted style={{ textAlign: 'center', marginTop: 40 }}>{state === 'listening' ? 'Listening… subtitles appear every few seconds.' : 'Press Start Listening.'}</Muted>}
      renderItem={({ item, index }) => {
        const latest = index === (big ? lines.slice(-4) : lines).length - 1;
        return (
          <View>
            {!big && <Text style={{ color: c.muted, fontSize: 13 }}>{item.original}</Text>}
            <Text style={{ color: latest ? c.text : c.muted, fontSize: font, fontWeight: '700', lineHeight: font * 1.3 }}>{item.translated}</Text>
            {!big && <Pressable onPress={() => !item.saved && save(item)} accessibilityRole="button" accessibilityLabel="Save sentence"><Text style={{ color: item.saved ? c.ok : c.accent, fontSize: 13, marginTop: 2 }}>{item.saved ? '★ Saved' : '☆ Save sentence'}</Text></Pressable>}
          </View>);
      }} />
  );

  return (
    <Screen>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <Muted>Subtitles in {langName(user!.nativeLang)}{detected && !lang ? ` · hearing ${langName(detected)}` : ''}</Muted>
        <LangButton value={lang} onChange={setLang} allowAuto autoLabel="Auto-detect" prefix="Speaker:" />
      </View>
      {subtitles(false)}
      {!!interim && <Muted style={{ fontStyle: 'italic' }}>{interim}</Muted>}
      <ErrorText msg={err} />
      {pending > 0 && <Muted>Translating {pending} segment{pending > 1 ? 's' : ''}…</Muted>}
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
        {state === 'idle' && <Btn title="Start listening" onPress={start} style={{ flex: 1 }} />}
        {state === 'listening' && <Btn title="⏸ Pause" kind="ghost" onPress={pause} style={{ flex: 1 }} />}
        {state === 'paused' && <Btn title="▶ Resume" onPress={start} style={{ flex: 1 }} />}
        {state !== 'idle' && <Btn title="Stop" kind="danger" onPress={stop} />}
      </View>
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 8, alignItems: 'center' }}>
        <Btn small kind="ghost" title="A−" onPress={() => setFont((f) => Math.max(14, f - 4))} />
        <Btn small kind="ghost" title="A+" onPress={() => setFont((f) => Math.min(72, f + 4))} />
        <Btn small kind="ghost" title="⛶ Full screen" onPress={() => setFull(true)} />
        <Btn small kind="ghost" title="Copy transcript" onPress={copy} disabled={!lines.length} />
        <Btn small kind="ghost" title="New session" onPress={newSession} disabled={state === 'listening'} />
      </View>
      <Muted style={{ marginTop: 6 }}>{free ? 'Free mode: choose the speaker\'s language; subtitles appear after each spoken phrase. Works in Chrome or Edge.' : `Subtitles update about every ${Math.round(SEGMENT_MS / 1000)}s plus processing time. Short pauses between segments can cost a word or two.`}</Muted>
      <Modal visible={full} animationType="fade" onRequestClose={() => setFull(false)}>
        <View style={{ flex: 1, backgroundColor: '#000', padding: 20, paddingTop: 40 }}>
          {subtitles(true)}
          <View style={{ flexDirection: 'row', gap: 8, justifyContent: 'center' }}>
            <Btn small kind="ghost" title="A−" onPress={() => setFont((f) => Math.max(14, f - 4))} />
            <Btn small kind="ghost" title="A+" onPress={() => setFont((f) => Math.min(72, f + 4))} />
            <Btn small title="Exit full screen" onPress={() => setFull(false)} />
          </View>
        </View>
      </Modal>
    </Screen>
  );
}
