import React, { useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useApp } from '../app-context';
import { Body, Btn, Card, Chip, ErrorText, H1, LangButton, Muted } from '../ui';
import { c } from '../theme';

export default function OnboardingScreen() {
  const { user, languages, voices, updateUser } = useApp();
  const [native, setNative] = useState(user!.nativeLang);
  const [preferred, setPreferred] = useState<string[]>(user!.preferredLangs);
  const [target, setTarget] = useState(user!.defaultTarget);
  const [voice, setVoice] = useState(user!.voice);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null);
  const toggle = (code: string) => setPreferred((p) => (p.includes(code) ? p.filter((x) => x !== code) : [...p, code]));
  const finish = async () => {
    setBusy(true); setErr(null);
    try { await updateUser({ nativeLang: native, preferredLangs: preferred, defaultTarget: target, voice, onboarded: true }); }
    catch (e: any) { setErr(e.message); setBusy(false); }
  };
  return (
    <ScrollView style={{ flex: 1, backgroundColor: c.bg }} contentContainerStyle={{ padding: 20, gap: 16, maxWidth: 640, width: '100%', alignSelf: 'center', paddingTop: 48 }}>
      <H1>Set up your languages</H1>
      <Muted>You only do this once. You can change it any time in Settings.</Muted>
      <Card style={{ gap: 8 }}>
        <Body>My native language</Body>
        <Muted>Everything you hear is translated into this.</Muted>
        <View style={{ flexDirection: 'row' }}><LangButton value={native} onChange={setNative} /></View>
      </Card>
      <Card style={{ gap: 8 }}>
        <Body>Other languages I use</Body>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {languages.filter((l) => l.code !== native).map((l) => <Chip key={l.code} label={l.name} active={preferred.includes(l.code)} onPress={() => toggle(l.code)} />)}
        </View>
      </Card>
      <Card style={{ gap: 8 }}>
        <Body>Default translation language</Body>
        <Muted>Used for text and camera translation when you reply to others.</Muted>
        <View style={{ flexDirection: 'row' }}><LangButton value={target} onChange={setTarget} /></View>
      </Card>
      <Card style={{ gap: 8 }}>
        <Body>Translated voice</Body>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{voices.map((v) => <Chip key={v} label={v} active={voice === v} onPress={() => setVoice(v)} />)}</View>
      </Card>
      <ErrorText msg={err} />
      <Btn title="Start using Lingora" onPress={finish} busy={busy} />
    </ScrollView>
  );
}
