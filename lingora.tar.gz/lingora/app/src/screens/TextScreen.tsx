import React, { useState } from 'react';
import { ScrollView, View } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { api } from '../api';
import { useApp } from '../app-context';
import { useHistory } from '../hooks';
import { Btn, Card, ErrorText, Field, H1, LangButton, Muted, Body } from '../ui';
import { c } from '../theme';

export default function TextScreen() {
  const { user, langName, speak, translate } = useApp();
  const { record, reset } = useHistory('text');
  const [text, setText] = useState('');
  const [target, setTarget] = useState(user!.nativeLang);
  const [res, setRes] = useState<any>(null);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const go = async () => {
    if (!text.trim()) return;
    setBusy(true); setErr(null); setSaved(false);
    try {
      const r = await translate({ text, target, note: true });
      setRes(r); reset();
      record({ original: text, translated: r.translation, sourceLang: r.source, targetLang: r.target });
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };
  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, gap: 12 }} keyboardShouldPersistTaps="handled">
      <H1>Text translation</H1>
      <Muted>Source language is detected automatically.</Muted>
      <Field multiline placeholder="Type or paste text…" value={text} onChangeText={setText} style={{ minHeight: 120, textAlignVertical: 'top' }} maxLength={5000} />
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <LangButton value={target} onChange={setTarget} prefix="Translate to:" />
        <Btn small kind="ghost" title="Paste" onPress={async () => setText(await Clipboard.getStringAsync())} />
        <Btn small kind="ghost" title="Clear" onPress={() => { setText(''); setRes(null); }} />
      </View>
      <Btn title="Translate" onPress={go} busy={busy} disabled={!text.trim()} />
      <ErrorText msg={err} />
      {res && (
        <Card style={{ gap: 8 }}>
          <Muted>Detected: {langName(res.source)} → {langName(res.target)}</Muted>
          <Body style={{ fontSize: 22, fontWeight: '700' }}>{res.translation}</Body>
          {!!res.note && <Body style={{ color: c.warn, fontSize: 14 }}>💡 {res.note}</Body>}
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            <Btn small kind="ghost" title="Copy" onPress={() => Clipboard.setStringAsync(res.translation)} />
            <Btn small kind="ghost" title="🔊 Listen" onPress={() => speak(res.translation, res.target).catch((e) => setErr(e.message))} />
            <Btn small kind="ghost" title={saved ? '★ Saved' : '☆ Save'} disabled={saved}
              onPress={async () => { try { await api.savePhrase({ folder: 'General', original: text, translated: res.translation, sourceLang: res.source, targetLang: res.target }); setSaved(true); } catch (e: any) { setErr(e.message); } }} />
          </View>
        </Card>)}
    </ScrollView>
  );
}
