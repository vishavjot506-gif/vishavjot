import React, { useEffect, useState } from 'react';
import { ScrollView, Switch, View } from 'react-native';
import { useApp } from '../app-context';
import { api } from '../api';
import { Btn, Card, Chip, ErrorText, H1, LangButton, Muted, Body } from '../ui';

export default function SettingsScreen() {
  const { user, languages, voices, updateUser, signOut, speak, langName, openaiAvailable } = useApp();
  const [agents, setAgents] = useState<{ name: string; title: string; job: string }[]>([]);
  useEffect(() => { api.engines().then((e: any) => setAgents(e.agents)).catch(() => {}); }, []);
  const [err, setErr] = useState<string | null>(null);
  const save = (p: any) => updateUser(p).catch((e) => setErr(e.message));
  const toggle = (code: string) => save({ preferredLangs: user!.preferredLangs.includes(code) ? user!.preferredLangs.filter((x) => x !== code) : [...user!.preferredLangs, code] });
  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, gap: 12 }}>
      <H1>Settings</H1>
      <Muted>{user!.email}</Muted>
      <ErrorText msg={err} />
      <Card style={{ gap: 8 }}>
        <Body>Engine</Body>
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Chip label="Free" active={user!.engine === 'free'} onPress={() => save({ engine: 'free' })} />
          {openaiAvailable && <Chip label="OpenAI (better quality, paid)" active={user!.engine === 'openai'} onPress={() => save({ engine: 'openai' })} />}
        </View>
        <Muted>{user!.engine === 'free'
          ? 'Free: browser speech recognition (Chrome/Edge), free translation service, device voice. No API cost. Quality is lower and you pick the speaker language yourself.'
          : 'OpenAI: automatic language detection, better translation, natural voices and phone-app microphone support. Uses your OpenAI credit.'}</Muted>
        {!openaiAvailable && <Muted>OpenAI is not set up on this server. Add OPENAI_API_KEY in server/.env and restart to enable it.</Muted>}
      </Card>
      <Card style={{ gap: 6 }}>
        <Body>Your 6 agents</Body>
        {agents.map((a) => <Muted key={a.name}>• {a.title}: {a.job}</Muted>)}
      </Card>
      <Card style={{ gap: 8 }}><Body>Native language</Body><View style={{ flexDirection: 'row' }}><LangButton value={user!.nativeLang} onChange={(c) => save({ nativeLang: c })} /></View></Card>
      <Card style={{ gap: 8 }}><Body>Default translation language</Body><View style={{ flexDirection: 'row' }}><LangButton value={user!.defaultTarget} onChange={(c) => save({ defaultTarget: c })} /></View></Card>
      <Card style={{ gap: 8 }}>
        <Body>Other languages I use</Body>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {languages.filter((l) => l.code !== user!.nativeLang).map((l) => <Chip key={l.code} label={l.name} active={user!.preferredLangs.includes(l.code)} onPress={() => toggle(l.code)} />)}
        </View>
      </Card>
      <Card style={{ gap: 8 }}>
        <Body>Translated voice</Body>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{voices.map((v) => <Chip key={v} label={v} active={user!.voice === v} onPress={() => save({ voice: v })} />)}</View>
        <Body>Speed: {user!.voiceSpeed.toFixed(2)}×</Body>
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          {[0.75, 1, 1.25].map((v) => <Chip key={v} label={`${v}×`} active={user!.voiceSpeed === v} onPress={() => save({ voiceSpeed: v })} />)}
          <Btn small kind="ghost" title="🔊 Test voice" onPress={() => speak(`Hello, I'm speaking ${langName(user!.nativeLang)}`).catch((e) => setErr(e.message))} />
        </View>
      </Card>
      <Card style={{ gap: 6 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Body>Save translation history</Body>
          <Switch value={user!.historyEnabled} onValueChange={(v) => save({ historyEnabled: v })} />
        </View>
        <Muted>Stores text transcripts only. Audio is processed and discarded, never saved.</Muted>
      </Card>
      <Card style={{ gap: 6 }}>
        <Body>Not available yet</Body>
        <Muted>Voice-based multi-speaker identification, group conversation, offline translation packs, earphone mode and floating subtitles are planned but not built.</Muted>
      </Card>
      <Btn kind="ghost" title="Sign out" onPress={signOut} />
      <Btn kind="danger" title="Delete my account and data" onPress={async () => { try { await api.deleteMe(); await signOut(); } catch (e: any) { setErr(e.message); } }} />
    </ScrollView>
  );
}
