import React, { useState } from 'react';
import { Image, ScrollView, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Clipboard from 'expo-clipboard';
import { api } from '../api';
import { useApp } from '../app-context';
import { useHistory } from '../hooks';
import { Btn, Card, ErrorText, H1, LangButton, Muted, Body } from '../ui';
import { c, r } from '../theme';

export default function CameraScreen() {
  const { user, langName, speak, free, translate } = useApp();
  const { record, reset } = useHistory('camera');
  const [target, setTarget] = useState(user!.nativeLang);
  const [srcLang, setSrcLang] = useState('');
  const [uri, setUri] = useState<string | null>(null);
  const [res, setRes] = useState<any>(null);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null);

  const run = async (picked: ImagePicker.ImagePickerResult) => {
    if (picked.canceled || !picked.assets[0]) return;
    const a = picked.assets[0];
    setUri(a.uri); setRes(null); setErr(null); setBusy(true);
    try {
      const type = a.mimeType && a.mimeType.startsWith('image/') ? a.mimeType : 'image/jpeg';
      const out = await api.translateImage({ uri: a.uri, name: a.fileName || 'photo.jpg', type }, target, srcLang || undefined, free);
      if (free && out.found) {
        // The server only read the text; the browser translates it (own free limit).
        const t = await translate({ text: out.extracted, source: out.source || undefined, target });
        out.translation = t.translation; out.source = out.source || t.source;
      }
      setRes(out); reset();
      if (out.found) record({ original: out.extracted, translated: out.translation, sourceLang: out.source || undefined, targetLang: out.target });
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };
  const camera = async () => {
    const p = await ImagePicker.requestCameraPermissionsAsync();
    if (!p.granted) { setErr('Camera permission is needed to take photos. You can still upload an image instead.'); return; }
    await run(await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], quality: 0.6 }));
  };
  const library = async () => run(await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.6 }));

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, gap: 12 }}>
      <H1>Camera translation</H1>
      <Muted>Menus, signs, notices and documents. Text is read by AI vision, so very small or blurry text may be missed.</Muted>
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <Btn title="📷 Take photo" onPress={camera} disabled={busy} style={{ flex: 1 }} />
        <Btn title="🖼 Upload image" kind="ghost" onPress={library} disabled={busy} style={{ flex: 1 }} />
      </View>
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <LangButton value={target} onChange={setTarget} prefix="Translate to:" />
        <LangButton value={srcLang} onChange={setSrcLang} allowAuto autoLabel="Auto" prefix="Text language:" />
      </View>
      {free && <Muted>Free mode reads text best when you pick the text's language above.</Muted>}
      <ErrorText msg={err} />
      {busy && <Muted>Reading and translating…</Muted>}
      {uri && <Image source={{ uri }} style={{ width: '100%', height: 220, borderRadius: r.md, backgroundColor: c.surface }} resizeMode="contain" />}
      {res && !res.found && <Card><Body>No readable text found in this image.</Body></Card>}
      {res?.found && (
        <View style={{ gap: 10 }}>
          <Card style={{ gap: 6 }}><Muted>Original{res.source ? ` (${langName(res.source)})` : ''}</Muted><Body>{res.extracted}</Body></Card>
          <Card style={{ gap: 6 }}>
            <Muted>Translation ({langName(res.target)})</Muted><Body style={{ fontSize: 19, fontWeight: '700' }}>{res.translation}</Body>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Btn small kind="ghost" title="Copy" onPress={() => Clipboard.setStringAsync(res.translation)} />
              <Btn small kind="ghost" title="🔊 Listen" onPress={() => speak(res.translation, res.target).catch((e) => setErr(e.message))} />
            </View>
          </Card>
        </View>)}
    </ScrollView>
  );
}
