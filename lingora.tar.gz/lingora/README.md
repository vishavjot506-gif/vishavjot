# LINGORA — Every Language. One Conversation.

One Expo (React Native) codebase for **web, Android and iOS**, plus a Node API they all share.

## Two engines, six agents
Each user picks an engine in Settings. **Free is the default and needs no API key.** OpenAI appears only if `OPENAI_API_KEY` is set on the server.

| Agent | Free engine | OpenAI engine |
|---|---|---|
| Listener (speech to text) | Browser Web Speech API (Chrome/Edge; you pick the speaker's language) | Whisper, with auto language detection |
| Detector (which language) | Offline `franc` + script rules | Whisper / GPT |
| Translator | MyMemory free API (or your own LibreTranslate) | GPT-4o-mini (+ cultural notes) |
| Voice | Device voice (`expo-speech`) | OpenAI `tts-1` |
| Vision (photo text) | Tesseract OCR on the server | GPT-4o-mini vision |
| Phrases (travel) | Uses the Translator agent | Uses the Translator agent |

Free limits: MyMemory allows roughly 5,000 characters/day (about 50,000 if you set `MYMEMORY_EMAIL`). Chrome's speech recognition sends audio to Google. Free speech recognition does **not** run in the Android/iOS apps (they need the OpenAI engine, or open the web app in Chrome on the phone). Tesseract downloads each language's data the first time it is used.

## Run it
```bash
# 1. API
cd server && cp .env.example .env      # add OPENAI_API_KEY and a long random JWT_SECRET
npm install && npm start               # http://localhost:4000

# 2. App
cd ../app && npm install
npm run web                            # browser (allow the microphone)
# phones: EXPO_PUBLIC_API_URL=http://<your-computer-LAN-IP>:4000 npx expo start
# Android emulator reaches the host at http://10.0.2.2:4000 (default)
```
Tests: `cd server && npm test` (uses a built-in fake AI, never the real API).
Keyless UI work: `LINGORA_MOCK_AI=1 npm start` returns canned output. Never use in production.

## What works
| Feature | How it works |
|---|---|
| Language settings | Native, extra, default-target language and voice stored on the account; editable anytime |
| Two-way conversation | Tap-to-talk, shared-device turn-taking; other speaker auto-detected; pause, mute, voice on/off, end; "Wrong language?" re-processes the clip with the language you pick |
| Live Listening | Mic is cut into ~4.5 s segments, each transcribed+translated; subtitles shown in order; font size, full screen, save sentence, copy transcript |
| Text translation | Auto-detect, copy, listen, save, cultural note when relevant |
| Camera translation | Photo/upload -> AI vision reads text -> translation shown beside original |
| Travel assistant | 7 scenarios x 7 phrases, translated on demand, cached, with playback |
| History | Opt-in, text only; delete one or all. Audio is never stored |
| Saved phrases | Folders, replay, move, delete (also used for Live "save sentence") |

## Honest limits
- **Not true streaming.** Live mode is chunked (about 5-8 s behind speech) and can lose a word at segment boundaries.
- **No voice-based speaker identification.** Speakers are whoever's button you tap.
- **Not built:** group conversation, offline packs, earphone mode, floating subtitles, per-speaker diarization (Settings says so).
- Whisper can mis-detect short or noisy clips; use "Wrong language?". Silence is filtered, not perfectly.
- Language/OCR quality is whatever the OpenAI models deliver; low-resource languages are weaker.
- Verified here: server tests (20 passing, free engine tested with a faked network), TypeScript, and Metro bundles for web/Android/iOS. **Not verified: real MyMemory/Tesseract downloads (this sandbox has no internet), a real OpenAI key, real devices**: microphone capture, audio playback on native, camera.

## Before production
Set `JWT_SECRET`, restrict `CORS_ORIGIN`, serve over HTTPS, put the API behind a managed DB (SQLite file is fine for one instance), add email verification/password reset, and add a privacy policy (audio is sent to OpenAI).
